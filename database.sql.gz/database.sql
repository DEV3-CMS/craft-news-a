-- MySQL dump 10.13  Distrib 8.0.33, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_wenzqbtkgfnbrvnlkejraidgcchvgcskrqif` (`ownerId`),
  CONSTRAINT `fk_hapluwfxeniuchtziesflqgklavughaixftq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wenzqbtkgfnbrvnlkejraidgcchvgcskrqif` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wfwwkhdnyyppcupsyvdrbzgaaeydqzfboeng` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_nxexffxgacppvxwkghjcbaeupkqvkjhxoqzc` (`dateRead`),
  KEY `fk_dgdflhenbjzytyxddpqotloiauudgqzxktow` (`pluginId`),
  CONSTRAINT `fk_dgdflhenbjzytyxddpqotloiauudgqzxktow` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gxkbjnhvzgvcqkhwmbhdlojmrrqytznrnqlf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_obrsbozmopuqndsevbcunaljielnlcunvizb` (`sessionId`,`volumeId`),
  KEY `idx_brlfwrkvfklqgkybbxtchhvvroybslhbirlq` (`volumeId`),
  CONSTRAINT `fk_wqqtjoeytsddocntemziiogmrjvhtdnwdfyv` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yfksxmkyipajmzrxzqvwoqjkdoookwpnqldw` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gssgjqzfknjclkkeahhjmoifcntfomozvxay` (`filename`,`folderId`),
  KEY `idx_cdypexzmxplsvkgtcysbhyeljadkpvetayga` (`folderId`),
  KEY `idx_onaoeyloargegkyjazumipoupnxugyvfazwc` (`volumeId`),
  KEY `fk_tjaffwnixrrlmgbroqbakzdrrposibnzjlsm` (`uploaderId`),
  CONSTRAINT `fk_okkxmtrftmupztixjdajhepjsobfakctgict` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qdcchfjqhwaanzdlysqcwcgulxvlvfunddce` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_seudffsyawnnbjyvjwbmxofvycbwjykhxggy` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tjaffwnixrrlmgbroqbakzdrrposibnzjlsm` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (3,1,1,1,'banner1.jpg','image',NULL,500,200,8080,NULL,NULL,NULL,'2023-12-04 13:49:00','2023-12-04 13:49:00','2023-12-04 13:49:00'),(4,1,1,1,'thumb1.jpg','image',NULL,400,300,11923,NULL,NULL,NULL,'2023-12-04 13:49:05','2023-12-04 13:49:05','2023-12-04 13:49:05'),(7,1,1,1,'banner2.jpg','image',NULL,500,200,7079,NULL,NULL,NULL,'2023-12-04 13:50:47','2023-12-04 13:50:47','2023-12-04 13:50:47'),(8,1,1,1,'thumb2.jpg','image',NULL,400,300,10407,NULL,NULL,NULL,'2023-12-04 13:50:51','2023-12-04 13:50:51','2023-12-04 13:50:51'),(11,1,1,1,'banner3.jpg','image',NULL,500,200,10204,NULL,NULL,NULL,'2023-12-04 13:51:30','2023-12-04 13:51:30','2023-12-04 13:51:30'),(12,1,1,1,'thumb3.jpg','image',NULL,400,300,12204,NULL,NULL,NULL,'2023-12-04 13:51:34','2023-12-04 13:51:34','2023-12-04 13:51:34'),(15,1,1,1,'banner2_2023-12-04-135241_jnph.jpg','image',NULL,500,200,7079,NULL,NULL,NULL,'2023-12-04 13:52:41','2023-12-04 13:52:41','2023-12-04 13:52:41'),(16,1,1,1,'thumb3_2023-12-04-135245_rxoi.jpg','image',NULL,400,300,12204,NULL,NULL,NULL,'2023-12-04 13:52:45','2023-12-04 13:52:45','2023-12-04 13:52:45'),(19,1,1,1,'luke-chesser-JKUTrJ4vK00-unsplash.jpg','image',NULL,1920,1280,219523,NULL,NULL,NULL,'2023-12-04 14:38:49','2023-12-04 14:38:49','2023-12-04 14:38:49'),(22,1,1,1,'luca-bravo-9l_326FISzk-unsplash-2.jpg','image',NULL,1920,1280,198173,NULL,NULL,NULL,'2023-12-04 14:38:59','2023-12-04 14:38:59','2023-12-04 14:38:59'),(24,1,1,1,'souvik-banerjee-WPrNEM_6dg-unsplash.jpg','image',NULL,1920,1280,139503,NULL,NULL,NULL,'2023-12-04 14:39:12','2023-12-04 14:39:12','2023-12-04 14:39:12'),(28,1,1,1,'ilya-pavlov-OqtafYT5kTw-unsplash.jpg','image',NULL,1920,1282,331641,NULL,NULL,NULL,'2023-12-04 14:39:38','2023-12-04 14:39:38','2023-12-04 14:39:38'),(31,1,1,1,'ttfb-map-warmed-full.png','image',NULL,2449,1098,345760,NULL,NULL,NULL,'2023-12-04 15:57:30','2023-12-04 15:57:30','2023-12-04 15:57:31'),(34,1,1,1,'walkator-klMii3cR9iI-unsplash.jpg','image',NULL,3000,4000,2836697,NULL,NULL,NULL,'2023-12-04 16:00:16','2023-12-04 16:00:16','2023-12-04 16:00:16'),(37,1,1,1,'sprigcart-preview.png','image',NULL,2200,1322,2178079,NULL,NULL,NULL,'2023-12-04 16:02:16','2023-12-04 16:02:16','2023-12-04 16:02:16');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vxabhqyctsuzqwohghfgtzvwgwaugmjhvgwm` (`groupId`),
  KEY `fk_odcrsaxilkejfkzqrogkxgrkugvtapbgzjzg` (`parentId`),
  CONSTRAINT `fk_jltnrrdsgcfozukispacadhetmgwtmgztogs` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_odcrsaxilkejfkzqrogkxgrkugvtapbgzjzg` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rkeptzckhxgtntrutifeqpifukmarczgvdut` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_auzjtyzsmyhhcxoglgkbmglppidvltlltclf` (`name`),
  KEY `idx_bkgwhjaerzromhytlynyxinxfmshpahbvyeb` (`handle`),
  KEY `idx_rhjayxkasvmqnfszbokgtcdauntxnhtystth` (`structureId`),
  KEY `idx_eyjfvqesyblcocnxrmiljkcdgwdetcoiyfdl` (`fieldLayoutId`),
  KEY `idx_qsswbuhwnlbtatfrtsonrahzgyoprzfnuzwx` (`dateDeleted`),
  CONSTRAINT `fk_ihntxknjhpbgdvllhncqxsficppyhuutuszr` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ylybaaqkwdypvscsaskiqbipyinogwdgghxf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ixantlzerhjiuflberizdegpieidiatdgiei` (`groupId`,`siteId`),
  KEY `idx_argpwjtyqfnvnogttqsdqohjpihdlwcmkscj` (`siteId`),
  CONSTRAINT `fk_dfqwhprpofflaydyafzvnzhkqinffdotprdx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vwsqowknidonnadygizcklsyeugkkczadmmn` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_exfkkfuvmtochujnntmavwinxgkvcdztxyho` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_ltjtmvnteaqnxucpvzrcqodfktssemgxgfhc` (`siteId`),
  KEY `fk_qdbimcpwopaziqgoerysyoqumuthkvizgtyk` (`userId`),
  CONSTRAINT `fk_ltjtmvnteaqnxucpvzrcqodfktssemgxgfhc` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qdbimcpwopaziqgoerysyoqumuthkvizgtyk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_yvvltfzmuzmilvrvldjldmrmnrcxcqzrazla` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (1,1,'email','2023-12-08 14:46:27',0,1),(1,1,'fullName','2023-12-08 14:46:27',0,1),(2,1,'postDate','2023-12-04 13:49:55',0,1),(2,1,'slug','2023-12-04 13:44:00',0,1),(2,1,'title','2023-12-04 13:44:00',0,1),(2,1,'uri','2023-12-04 13:44:00',0,1),(6,1,'postDate','2023-12-04 13:51:12',0,1),(6,1,'slug','2023-12-04 13:50:43',0,1),(6,1,'title','2023-12-04 13:50:43',0,1),(6,1,'uri','2023-12-04 13:50:43',0,1),(10,1,'postDate','2023-12-04 13:51:48',0,1),(10,1,'slug','2023-12-04 13:51:26',0,1),(10,1,'title','2023-12-04 13:51:26',0,1),(10,1,'uri','2023-12-04 13:51:26',0,1),(14,1,'postDate','2023-12-04 13:53:29',0,1),(14,1,'slug','2023-12-04 13:52:31',0,1),(14,1,'title','2023-12-04 13:52:31',0,1),(14,1,'uri','2023-12-04 13:52:31',0,1),(30,1,'postDate','2023-12-04 15:57:34',0,1),(30,1,'slug','2023-12-04 15:56:51',0,1),(30,1,'title','2023-12-04 15:56:51',0,1),(30,1,'uri','2023-12-04 15:56:51',0,1),(33,1,'postDate','2023-12-04 16:00:19',0,1),(33,1,'slug','2023-12-04 15:59:07',0,1),(33,1,'title','2023-12-04 15:59:08',0,1),(33,1,'uri','2023-12-04 15:59:07',0,1),(36,1,'postDate','2023-12-04 16:02:18',0,1),(36,1,'slug','2023-12-04 16:01:38',0,1),(36,1,'title','2023-12-04 16:01:38',0,1),(36,1,'uri','2023-12-04 16:01:38',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_syrmphkvmrkgcgfxyrytqpdfxmjbgaakbcov` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_yshrsgthyhmegpwfwtzyvnkgvtjbjzdvgssj` (`siteId`),
  KEY `fk_ivvbjzwjytzsqoenhbbknefpgzbbeyeevqbf` (`fieldId`),
  KEY `fk_temlyouumqtcttlmpyrspcfejjprrqtzgyrp` (`userId`),
  CONSTRAINT `fk_cmxdvhkyuiybwfhyyjhhdeskhuoifdrbxoag` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ivvbjzwjytzsqoenhbbknefpgzbbeyeevqbf` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_temlyouumqtcttlmpyrspcfejjprrqtzgyrp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_yshrsgthyhmegpwfwtzyvnkgvtjbjzdvgssj` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (2,1,1,'2023-12-04 13:49:45',0,1),(2,1,2,'2023-12-04 13:49:52',0,1),(2,1,3,'2023-12-04 14:39:39',0,1),(6,1,1,'2023-12-04 13:51:01',0,1),(6,1,2,'2023-12-04 13:51:11',0,1),(6,1,3,'2023-12-04 14:39:00',0,1),(10,1,1,'2023-12-04 13:51:42',0,1),(10,1,2,'2023-12-04 13:51:48',0,1),(10,1,3,'2023-12-04 14:39:16',0,1),(14,1,1,'2023-12-04 13:53:20',0,1),(14,1,2,'2023-12-04 13:53:29',0,1),(14,1,3,'2023-12-04 14:38:51',0,1),(30,1,1,'2023-12-04 15:57:13',0,1),(30,1,3,'2023-12-04 15:57:31',0,1),(30,1,5,'2023-12-04 15:56:11',0,1),(30,1,6,'2023-12-04 15:56:10',0,1),(33,1,1,'2023-12-04 15:58:56',0,1),(33,1,3,'2023-12-04 16:00:17',0,1),(33,1,5,'2023-12-04 15:58:45',0,1),(33,1,6,'2023-12-04 15:58:44',0,1),(36,1,1,'2023-12-04 16:01:17',0,1),(36,1,3,'2023-12-04 16:02:17',0,1),(36,1,5,'2023-12-04 16:01:03',0,1),(36,1,6,'2023-12-04 16:01:01',0,1),(39,1,7,'2023-12-04 16:33:35',0,1),(53,1,7,'2023-12-04 16:42:35',0,1),(61,1,7,'2023-12-04 16:54:11',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_introText_yprwwwti` text,
  `field_fullText_gninfktw` text,
  `field_rating_strxivmx` smallint DEFAULT NULL,
  `field_storeUrl_kztiozrj` varchar(255) DEFAULT NULL,
  `field_richText_xnzochyb` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iajpoohohjaegsvijtxddwxvbhebbatxelfl` (`elementId`,`siteId`),
  KEY `idx_mrbpxndvirprkxgazwmxmwookhweejuedtvx` (`siteId`),
  KEY `idx_grfilxbrlfkhrnxyxtyznughdmzsnokofqhb` (`title`),
  CONSTRAINT `fk_kcftsuocyoawbtxzvzkkixecezhdxbddzowv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qoxdwajzegqdkcavopterspmpikhrrlgxhnb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,1,NULL,'2023-12-04 13:07:51','2023-12-08 14:46:27','f98c0704-6460-4b84-ba1e-60d0ff17f5b9',NULL,NULL,NULL,NULL,NULL),(2,2,1,'flashy article about craft CMS','2023-12-04 13:43:45','2023-12-04 14:39:38','811d1c15-3145-4dc6-9809-0fcd5e76b41f','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sed mi neque. Quisque ultrices bibendum neque vitae malesuada. Vivamus a purus nunc.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sed mi neque. Quisque ultrices bibendum neque vitae malesuada. Vivamus a purus nunc. In vitae felis commodo, ullamcorper felis nec, pretium sapien. Vivamus ac porta ligula. Maecenas nec turpis neque. Duis fermentum tristique quam, quis ullamcorper turpis ornare at. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Duis ut maximus eros. Nulla eu massa ligula. Pellentesque semper laoreet fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus vitae dolor ex. Proin euismod accumsan velit tincidunt ornare. Nulla vitae molestie orci.  Phasellus aliquet vitae erat a vehicula. Suspendisse potenti. Suspendisse dictum ultricies aliquet. Pellentesque pharetra lacus quis tellus luctus, eleifend faucibus quam dictum. Aliquam consequat nulla sit amet quam semper rhoncus. Sed orci sapien, rutrum pretium consequat eu, tempor non massa. Fusce sit amet mollis justo, eget elementum mauris. Suspendisse eget felis lectus. Sed efficitur, orci sed tempus volutpat, neque orci sollicitudin sem, vitae vehicula lorem justo vitae mi. Integer nisi metus, fermentum sed auctor ut, porta eu lorem. Suspendisse at semper nibh.',NULL,NULL,NULL),(3,3,1,'Banner1','2023-12-04 13:49:00','2023-12-04 13:49:00','4784fb84-667d-474a-a861-a739033ad751',NULL,NULL,NULL,NULL,NULL),(4,4,1,'Thumb1','2023-12-04 13:49:05','2023-12-04 13:49:05','d9dc148e-53d8-4f90-b19a-db36775ed6c6',NULL,NULL,NULL,NULL,NULL),(5,5,1,'flashy article about craft CMS','2023-12-04 13:49:55','2023-12-04 13:49:55','ee726f3a-70bd-49c1-98b5-29ca7bc9883f','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sed mi neque. Quisque ultrices bibendum neque vitae malesuada. Vivamus a purus nunc.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sed mi neque. Quisque ultrices bibendum neque vitae malesuada. Vivamus a purus nunc. In vitae felis commodo, ullamcorper felis nec, pretium sapien. Vivamus ac porta ligula. Maecenas nec turpis neque. Duis fermentum tristique quam, quis ullamcorper turpis ornare at. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Duis ut maximus eros. Nulla eu massa ligula. Pellentesque semper laoreet fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus vitae dolor ex. Proin euismod accumsan velit tincidunt ornare. Nulla vitae molestie orci.  Phasellus aliquet vitae erat a vehicula. Suspendisse potenti. Suspendisse dictum ultricies aliquet. Pellentesque pharetra lacus quis tellus luctus, eleifend faucibus quam dictum. Aliquam consequat nulla sit amet quam semper rhoncus. Sed orci sapien, rutrum pretium consequat eu, tempor non massa. Fusce sit amet mollis justo, eget elementum mauris. Suspendisse eget felis lectus. Sed efficitur, orci sed tempus volutpat, neque orci sollicitudin sem, vitae vehicula lorem justo vitae mi. Integer nisi metus, fermentum sed auctor ut, porta eu lorem. Suspendisse at semper nibh.',NULL,NULL,NULL),(6,6,1,'everything you need to know about CraftCMS','2023-12-04 13:50:29','2023-12-04 14:39:00','109e1041-14be-4a0e-b70c-5a087b82e96e','Cras fermentum enim sed lacus blandit, vitae tempor nibh tincidunt. Praesent dolor justo, vulputate sit amet consequat consectetur, gravida ac risus.','Cras fermentum enim sed lacus blandit, vitae tempor nibh tincidunt. Praesent dolor justo, vulputate sit amet consequat consectetur, gravida ac risus. In in risus tortor. Quisque tempor lobortis maximus. Ut hendrerit eleifend libero, non aliquet neque. Aliquam quis risus at purus accumsan finibus sed at lacus. Nunc maximus massa quis gravida egestas.  Suspendisse hendrerit est et purus tempor, sed pretium urna interdum. Nullam sodales scelerisque mi, ac ultricies nisi porttitor at. Aenean aliquam, odio eu commodo fermentum, felis enim lobortis nunc, in rhoncus eros ex non urna. Integer sed commodo tortor. Proin accumsan tempor orci, eget facilisis ligula tempus id. In ut dui iaculis, eleifend ex nec, porta risus. Sed felis urna, rhoncus nec aliquet quis, ultrices et nisi. Sed et dignissim lacus, eget pretium mauris.  Donec bibendum rhoncus nibh ac efficitur. Maecenas porta purus ut sagittis iaculis. In lacinia leo vel urna scelerisque dignissim. Praesent nec quam laoreet, molestie metus nec, interdum est. Maecenas volutpat vehicula lacinia. Nulla tempus iaculis scelerisque. Sed non sollicitudin ipsum, ac iaculis velit. Nullam quis lacus eget libero pellentesque suscipit. Nam consequat justo sed felis maximus placerat. Praesent sed blandit est. Sed pellentesque posuere aliquet. Nunc magna est, eleifend eleifend tellus in, faucibus faucibus sem. Fusce rhoncus massa eget vestibulum iaculis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.',NULL,NULL,NULL),(7,7,1,'Banner2','2023-12-04 13:50:47','2023-12-04 13:50:47','47a5df67-0e7e-43ff-a59a-6f267562b698',NULL,NULL,NULL,NULL,NULL),(8,8,1,'Thumb2','2023-12-04 13:50:51','2023-12-04 13:50:51','d99aefae-e57d-4383-a072-169501707659',NULL,NULL,NULL,NULL,NULL),(9,9,1,'everything you need to know about CraftCMS','2023-12-04 13:51:12','2023-12-04 13:51:12','d66abf34-e55a-4162-9a6d-7fef5cfda893','Cras fermentum enim sed lacus blandit, vitae tempor nibh tincidunt. Praesent dolor justo, vulputate sit amet consequat consectetur, gravida ac risus.','Cras fermentum enim sed lacus blandit, vitae tempor nibh tincidunt. Praesent dolor justo, vulputate sit amet consequat consectetur, gravida ac risus. In in risus tortor. Quisque tempor lobortis maximus. Ut hendrerit eleifend libero, non aliquet neque. Aliquam quis risus at purus accumsan finibus sed at lacus. Nunc maximus massa quis gravida egestas.  Suspendisse hendrerit est et purus tempor, sed pretium urna interdum. Nullam sodales scelerisque mi, ac ultricies nisi porttitor at. Aenean aliquam, odio eu commodo fermentum, felis enim lobortis nunc, in rhoncus eros ex non urna. Integer sed commodo tortor. Proin accumsan tempor orci, eget facilisis ligula tempus id. In ut dui iaculis, eleifend ex nec, porta risus. Sed felis urna, rhoncus nec aliquet quis, ultrices et nisi. Sed et dignissim lacus, eget pretium mauris.  Donec bibendum rhoncus nibh ac efficitur. Maecenas porta purus ut sagittis iaculis. In lacinia leo vel urna scelerisque dignissim. Praesent nec quam laoreet, molestie metus nec, interdum est. Maecenas volutpat vehicula lacinia. Nulla tempus iaculis scelerisque. Sed non sollicitudin ipsum, ac iaculis velit. Nullam quis lacus eget libero pellentesque suscipit. Nam consequat justo sed felis maximus placerat. Praesent sed blandit est. Sed pellentesque posuere aliquet. Nunc magna est, eleifend eleifend tellus in, faucibus faucibus sem. Fusce rhoncus massa eget vestibulum iaculis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.',NULL,NULL,NULL),(10,10,1,'craft cms vs drupal vs wordpress','2023-12-04 13:51:15','2023-12-04 14:39:15','bad79758-c08f-402d-9c85-0366e927f15e','Phasellus aliquet vitae erat a vehicula. Suspendisse potenti. Suspendisse dictum ultricies aliquet. Pellentesque pharetra lacus quis tellus luctus, eleifend faucibus quam dictum. Aliquam consequat nulla sit amet quam semper rhoncus. Sed orci sapien, rutrum pretium consequat eu, tempor non massa.','Phasellus aliquet vitae erat a vehicula. Suspendisse potenti. Suspendisse dictum ultricies aliquet. Pellentesque pharetra lacus quis tellus luctus, eleifend faucibus quam dictum. Aliquam consequat nulla sit amet quam semper rhoncus. Sed orci sapien, rutrum pretium consequat eu, tempor non massa. Fusce sit amet mollis justo, eget elementum mauris. Suspendisse eget felis lectus. Sed efficitur, orci sed tempus volutpat, neque orci sollicitudin sem, vitae vehicula lorem justo vitae mi. Integer nisi metus, fermentum sed auctor ut, porta eu lorem. Suspendisse at semper nibh.  Cras fermentum enim sed lacus blandit, vitae tempor nibh tincidunt. Praesent dolor justo, vulputate sit amet consequat consectetur, gravida ac risus. In in risus tortor. Quisque tempor lobortis maximus. Ut hendrerit eleifend libero, non aliquet neque. Aliquam quis risus at purus accumsan finibus sed at lacus. Nunc maximus massa quis gravida egestas.',NULL,NULL,NULL),(11,11,1,'Banner3','2023-12-04 13:51:30','2023-12-04 13:51:30','65b7db4d-03a2-4be9-b190-3b9a9ee5158a',NULL,NULL,NULL,NULL,NULL),(12,12,1,'Thumb3','2023-12-04 13:51:34','2023-12-04 13:51:34','2787dc58-fe64-4d4b-841e-799c5f7b32a7',NULL,NULL,NULL,NULL,NULL),(13,13,1,'craft cms vs drupal vs wordpress','2023-12-04 13:51:48','2023-12-04 13:51:48','2c78b17e-4123-4654-8b16-da9be3212e91','Phasellus aliquet vitae erat a vehicula. Suspendisse potenti. Suspendisse dictum ultricies aliquet. Pellentesque pharetra lacus quis tellus luctus, eleifend faucibus quam dictum. Aliquam consequat nulla sit amet quam semper rhoncus. Sed orci sapien, rutrum pretium consequat eu, tempor non massa.','Phasellus aliquet vitae erat a vehicula. Suspendisse potenti. Suspendisse dictum ultricies aliquet. Pellentesque pharetra lacus quis tellus luctus, eleifend faucibus quam dictum. Aliquam consequat nulla sit amet quam semper rhoncus. Sed orci sapien, rutrum pretium consequat eu, tempor non massa. Fusce sit amet mollis justo, eget elementum mauris. Suspendisse eget felis lectus. Sed efficitur, orci sed tempus volutpat, neque orci sollicitudin sem, vitae vehicula lorem justo vitae mi. Integer nisi metus, fermentum sed auctor ut, porta eu lorem. Suspendisse at semper nibh.  Cras fermentum enim sed lacus blandit, vitae tempor nibh tincidunt. Praesent dolor justo, vulputate sit amet consequat consectetur, gravida ac risus. In in risus tortor. Quisque tempor lobortis maximus. Ut hendrerit eleifend libero, non aliquet neque. Aliquam quis risus at purus accumsan finibus sed at lacus. Nunc maximus massa quis gravida egestas.',NULL,NULL,NULL),(14,14,1,'how to improve Craft CMS performance','2023-12-04 13:51:50','2023-12-04 14:38:51','eda4a860-3d7d-4060-b298-dd9f0f6df085','Mauris pellentesque fringilla magna ut ullamcorper. Suspendisse molestie eu nunc et interdum. Vivamus eu ex metus. Quisque fringilla tortor rutrum viverra congue. Aliquam id ex et arcu lacinia imperdiet non eget quam. Donec semper eu ante id condimentum. Curabitur consequat ligula id porttitor rhoncus.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae semper velit. Aliquam vitae mauris erat. Nullam non dolor et augue congue bibendum et et risus. Proin imperdiet magna dui, sit amet suscipit tortor iaculis blandit. Sed gravida libero at arcu interdum maximus. Vivamus congue ornare nunc ac pellentesque. Nunc eget aliquam leo, vitae malesuada ligula. Donec malesuada augue eu vestibulum sagittis. Sed in velit iaculis, blandit neque vel, ornare tortor.  Integer pretium odio dolor. Suspendisse quis iaculis nunc. Morbi interdum arcu nunc, ac sollicitudin nibh porttitor nec. In blandit auctor metus, eu efficitur nulla ullamcorper quis. Donec vulputate rhoncus mollis. Nam non massa sed magna interdum tempor quis quis odio. Etiam dictum ac nulla lobortis auctor. Duis dui augue, porttitor at lacinia non, scelerisque non nisi. Suspendisse pharetra justo non libero rutrum euismod. Curabitur ac viverra neque. Donec cursus vel purus quis venenatis. Etiam posuere in massa id interdum.  Mauris pellentesque fringilla magna ut ullamcorper. Suspendisse molestie eu nunc et interdum. Vivamus eu ex metus. Quisque fringilla tortor rutrum viverra congue. Aliquam id ex et arcu lacinia imperdiet non eget quam. Donec semper eu ante id condimentum. Curabitur consequat ligula id porttitor rhoncus. Integer maximus ex ac magna fringilla, id tempor metus egestas. Praesent accumsan in urna sit amet convallis. Aliquam erat volutpat.',NULL,NULL,NULL),(15,15,1,'Banner2','2023-12-04 13:52:41','2023-12-04 13:52:41','97a61d1f-cad5-4687-a67a-8cf463d165b5',NULL,NULL,NULL,NULL,NULL),(16,16,1,'Thumb3','2023-12-04 13:52:45','2023-12-04 13:52:45','610eb281-1345-4926-b417-71f995ba7dcb',NULL,NULL,NULL,NULL,NULL),(17,17,1,'how to improve Craft CMS performance','2023-12-04 13:53:30','2023-12-04 13:53:30','6488de97-d238-4e7a-a25f-523d13ac24c7','Mauris pellentesque fringilla magna ut ullamcorper. Suspendisse molestie eu nunc et interdum. Vivamus eu ex metus. Quisque fringilla tortor rutrum viverra congue. Aliquam id ex et arcu lacinia imperdiet non eget quam. Donec semper eu ante id condimentum. Curabitur consequat ligula id porttitor rhoncus.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae semper velit. Aliquam vitae mauris erat. Nullam non dolor et augue congue bibendum et et risus. Proin imperdiet magna dui, sit amet suscipit tortor iaculis blandit. Sed gravida libero at arcu interdum maximus. Vivamus congue ornare nunc ac pellentesque. Nunc eget aliquam leo, vitae malesuada ligula. Donec malesuada augue eu vestibulum sagittis. Sed in velit iaculis, blandit neque vel, ornare tortor.  Integer pretium odio dolor. Suspendisse quis iaculis nunc. Morbi interdum arcu nunc, ac sollicitudin nibh porttitor nec. In blandit auctor metus, eu efficitur nulla ullamcorper quis. Donec vulputate rhoncus mollis. Nam non massa sed magna interdum tempor quis quis odio. Etiam dictum ac nulla lobortis auctor. Duis dui augue, porttitor at lacinia non, scelerisque non nisi. Suspendisse pharetra justo non libero rutrum euismod. Curabitur ac viverra neque. Donec cursus vel purus quis venenatis. Etiam posuere in massa id interdum.  Mauris pellentesque fringilla magna ut ullamcorper. Suspendisse molestie eu nunc et interdum. Vivamus eu ex metus. Quisque fringilla tortor rutrum viverra congue. Aliquam id ex et arcu lacinia imperdiet non eget quam. Donec semper eu ante id condimentum. Curabitur consequat ligula id porttitor rhoncus. Integer maximus ex ac magna fringilla, id tempor metus egestas. Praesent accumsan in urna sit amet convallis. Aliquam erat volutpat.',NULL,NULL,NULL),(19,19,1,'Luke chesser JKU Tr J4v K00 unsplash','2023-12-04 14:38:49','2023-12-04 14:38:49','f2ffa49c-20cb-440c-9c76-c0d681dbc1dc',NULL,NULL,NULL,NULL,NULL),(20,20,1,'how to improve Craft CMS performance','2023-12-04 14:38:51','2023-12-04 14:38:51','300caee3-98ff-4405-a1d4-3cd51bc5269f','Mauris pellentesque fringilla magna ut ullamcorper. Suspendisse molestie eu nunc et interdum. Vivamus eu ex metus. Quisque fringilla tortor rutrum viverra congue. Aliquam id ex et arcu lacinia imperdiet non eget quam. Donec semper eu ante id condimentum. Curabitur consequat ligula id porttitor rhoncus.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae semper velit. Aliquam vitae mauris erat. Nullam non dolor et augue congue bibendum et et risus. Proin imperdiet magna dui, sit amet suscipit tortor iaculis blandit. Sed gravida libero at arcu interdum maximus. Vivamus congue ornare nunc ac pellentesque. Nunc eget aliquam leo, vitae malesuada ligula. Donec malesuada augue eu vestibulum sagittis. Sed in velit iaculis, blandit neque vel, ornare tortor.  Integer pretium odio dolor. Suspendisse quis iaculis nunc. Morbi interdum arcu nunc, ac sollicitudin nibh porttitor nec. In blandit auctor metus, eu efficitur nulla ullamcorper quis. Donec vulputate rhoncus mollis. Nam non massa sed magna interdum tempor quis quis odio. Etiam dictum ac nulla lobortis auctor. Duis dui augue, porttitor at lacinia non, scelerisque non nisi. Suspendisse pharetra justo non libero rutrum euismod. Curabitur ac viverra neque. Donec cursus vel purus quis venenatis. Etiam posuere in massa id interdum.  Mauris pellentesque fringilla magna ut ullamcorper. Suspendisse molestie eu nunc et interdum. Vivamus eu ex metus. Quisque fringilla tortor rutrum viverra congue. Aliquam id ex et arcu lacinia imperdiet non eget quam. Donec semper eu ante id condimentum. Curabitur consequat ligula id porttitor rhoncus. Integer maximus ex ac magna fringilla, id tempor metus egestas. Praesent accumsan in urna sit amet convallis. Aliquam erat volutpat.',NULL,NULL,NULL),(22,22,1,'Luca bravo 9l 326 FI Szk unsplash 2','2023-12-04 14:38:59','2023-12-04 14:38:59','fe2e3158-72cc-4f0c-9d42-f739cc86b6e5',NULL,NULL,NULL,NULL,NULL),(23,23,1,'everything you need to know about CraftCMS','2023-12-04 14:39:00','2023-12-04 14:39:00','f1e68f3f-aa09-46ee-8815-8f370fa4af83','Cras fermentum enim sed lacus blandit, vitae tempor nibh tincidunt. Praesent dolor justo, vulputate sit amet consequat consectetur, gravida ac risus.','Cras fermentum enim sed lacus blandit, vitae tempor nibh tincidunt. Praesent dolor justo, vulputate sit amet consequat consectetur, gravida ac risus. In in risus tortor. Quisque tempor lobortis maximus. Ut hendrerit eleifend libero, non aliquet neque. Aliquam quis risus at purus accumsan finibus sed at lacus. Nunc maximus massa quis gravida egestas.  Suspendisse hendrerit est et purus tempor, sed pretium urna interdum. Nullam sodales scelerisque mi, ac ultricies nisi porttitor at. Aenean aliquam, odio eu commodo fermentum, felis enim lobortis nunc, in rhoncus eros ex non urna. Integer sed commodo tortor. Proin accumsan tempor orci, eget facilisis ligula tempus id. In ut dui iaculis, eleifend ex nec, porta risus. Sed felis urna, rhoncus nec aliquet quis, ultrices et nisi. Sed et dignissim lacus, eget pretium mauris.  Donec bibendum rhoncus nibh ac efficitur. Maecenas porta purus ut sagittis iaculis. In lacinia leo vel urna scelerisque dignissim. Praesent nec quam laoreet, molestie metus nec, interdum est. Maecenas volutpat vehicula lacinia. Nulla tempus iaculis scelerisque. Sed non sollicitudin ipsum, ac iaculis velit. Nullam quis lacus eget libero pellentesque suscipit. Nam consequat justo sed felis maximus placerat. Praesent sed blandit est. Sed pellentesque posuere aliquet. Nunc magna est, eleifend eleifend tellus in, faucibus faucibus sem. Fusce rhoncus massa eget vestibulum iaculis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.',NULL,NULL,NULL),(24,24,1,'Souvik banerjee W Pr NEM 6dg unsplash','2023-12-04 14:39:12','2023-12-04 14:39:12','d00526a9-d134-4dba-966b-4e756479e3de',NULL,NULL,NULL,NULL,NULL),(26,26,1,'craft cms vs drupal vs wordpress','2023-12-04 14:39:15','2023-12-04 14:39:15','a5890dd7-ffa3-48f7-a3af-fc7708e6b36c','Phasellus aliquet vitae erat a vehicula. Suspendisse potenti. Suspendisse dictum ultricies aliquet. Pellentesque pharetra lacus quis tellus luctus, eleifend faucibus quam dictum. Aliquam consequat nulla sit amet quam semper rhoncus. Sed orci sapien, rutrum pretium consequat eu, tempor non massa.','Phasellus aliquet vitae erat a vehicula. Suspendisse potenti. Suspendisse dictum ultricies aliquet. Pellentesque pharetra lacus quis tellus luctus, eleifend faucibus quam dictum. Aliquam consequat nulla sit amet quam semper rhoncus. Sed orci sapien, rutrum pretium consequat eu, tempor non massa. Fusce sit amet mollis justo, eget elementum mauris. Suspendisse eget felis lectus. Sed efficitur, orci sed tempus volutpat, neque orci sollicitudin sem, vitae vehicula lorem justo vitae mi. Integer nisi metus, fermentum sed auctor ut, porta eu lorem. Suspendisse at semper nibh.  Cras fermentum enim sed lacus blandit, vitae tempor nibh tincidunt. Praesent dolor justo, vulputate sit amet consequat consectetur, gravida ac risus. In in risus tortor. Quisque tempor lobortis maximus. Ut hendrerit eleifend libero, non aliquet neque. Aliquam quis risus at purus accumsan finibus sed at lacus. Nunc maximus massa quis gravida egestas.',NULL,NULL,NULL),(28,28,1,'Ilya pavlov Oqtaf YT5k Tw unsplash','2023-12-04 14:39:37','2023-12-04 14:39:38','21897233-81c4-4bc5-963f-a25b61c4d3fd',NULL,NULL,NULL,NULL,NULL),(29,29,1,'flashy article about craft CMS','2023-12-04 14:39:39','2023-12-04 14:39:39','4aa14110-b718-455c-a590-8b9890b85b61','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sed mi neque. Quisque ultrices bibendum neque vitae malesuada. Vivamus a purus nunc.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sed mi neque. Quisque ultrices bibendum neque vitae malesuada. Vivamus a purus nunc. In vitae felis commodo, ullamcorper felis nec, pretium sapien. Vivamus ac porta ligula. Maecenas nec turpis neque. Duis fermentum tristique quam, quis ullamcorper turpis ornare at. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Duis ut maximus eros. Nulla eu massa ligula. Pellentesque semper laoreet fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus vitae dolor ex. Proin euismod accumsan velit tincidunt ornare. Nulla vitae molestie orci.  Phasellus aliquet vitae erat a vehicula. Suspendisse potenti. Suspendisse dictum ultricies aliquet. Pellentesque pharetra lacus quis tellus luctus, eleifend faucibus quam dictum. Aliquam consequat nulla sit amet quam semper rhoncus. Sed orci sapien, rutrum pretium consequat eu, tempor non massa. Fusce sit amet mollis justo, eget elementum mauris. Suspendisse eget felis lectus. Sed efficitur, orci sed tempus volutpat, neque orci sollicitudin sem, vitae vehicula lorem justo vitae mi. Integer nisi metus, fermentum sed auctor ut, porta eu lorem. Suspendisse at semper nibh.',NULL,NULL,NULL),(30,30,1,'Cache Igniter: fire up your sites performance!','2023-12-04 15:55:59','2023-12-04 15:57:34','6e651b8d-6bc1-4382-a4b3-359971f82b49','Keeps your site’s cache warm around the globe and around the clock.',NULL,4,'https://plugins.craftcms.com/cache-igniter?craft4',NULL),(31,31,1,'Ttfb map warmed full','2023-12-04 15:57:30','2023-12-04 15:57:30','51273d34-0118-4ab7-b718-4c3d9a6de891',NULL,NULL,NULL,NULL,NULL),(32,32,1,'Cache Igniter: fire up your sites performance!','2023-12-04 15:57:34','2023-12-04 15:57:34','d7fbceef-5ff1-459c-9bac-6493f1ae90be','Keeps your site’s cache warm around the globe and around the clock.',NULL,4,'https://plugins.craftcms.com/cache-igniter?craft4',NULL),(33,33,1,'Minify your HTML, CSS and JS','2023-12-04 15:58:25','2023-12-04 16:00:19','326c518b-6382-4311-9031-1970edf726af','Minify adds several block tags for minifying HTML, CSS, and JS inline in your templates. Minify does not minify external CSS or JS files.',NULL,3,'https://plugins.craftcms.com/minify?craft4',NULL),(34,34,1,'Walkator kl Mii3c R9i I unsplash','2023-12-04 16:00:15','2023-12-04 16:00:16','31811b47-73f6-433a-8027-689ab3d2e437',NULL,NULL,NULL,NULL,NULL),(35,35,1,'Minify your HTML, CSS and JS','2023-12-04 16:00:19','2023-12-04 16:00:19','065fc50d-de74-4aff-9d7a-5da970d49771','Minify adds several block tags for minifying HTML, CSS, and JS inline in your templates. Minify does not minify external CSS or JS files.',NULL,3,'https://plugins.craftcms.com/minify?craft4',NULL),(36,36,1,'Sprig: reactive components for Twig','2023-12-04 16:00:21','2023-12-04 16:02:18','4f98a1a6-620f-48b3-baf8-b5c06125e77e','Sprig is a free plugin that allows you to create reactive components from Twig templates and/​or PHP classes.',NULL,2,'https://plugins.craftcms.com/sprig?craft4',NULL),(37,37,1,'Sprigcart preview','2023-12-04 16:02:15','2023-12-04 16:02:16','12fea36d-d5d6-4899-8155-52244c393d6f',NULL,NULL,NULL,NULL,NULL),(38,38,1,'Sprig: reactive components for Twig','2023-12-04 16:02:18','2023-12-04 16:02:18','b3b5d393-cd65-4b30-a642-504c494fb7fd','Sprig is a free plugin that allows you to create reactive components from Twig templates and/​or PHP classes.',NULL,2,'https://plugins.craftcms.com/sprig?craft4',NULL),(39,39,1,'footer','2023-12-04 16:20:03','2023-12-04 16:33:35','5fbc6e85-156a-4780-9c3e-f642928d0d32',NULL,NULL,NULL,NULL,'<p>With a commitment to quality content for the Craft-community.</p>\n<p><a href=\"#\">privacy policy</a></p>'),(40,40,1,'footer','2023-12-04 16:20:03','2023-12-04 16:20:03','75007cdf-9b1f-47b6-8566-64f5fd07f03b',NULL,NULL,NULL,NULL,NULL),(41,41,1,'footer','2023-12-04 16:20:03','2023-12-04 16:20:03','b51444df-446f-488c-89bd-1713388667f3',NULL,NULL,NULL,NULL,NULL),(42,42,1,'footer','2023-12-04 16:26:17','2023-12-04 16:26:17','9d50fdc9-e025-457d-8d0b-17ee0a97c6d7',NULL,NULL,NULL,NULL,NULL),(44,44,1,'footer','2023-12-04 16:28:14','2023-12-04 16:28:14','9c797409-fcf7-45b1-87ad-5e3c3cd77341',NULL,NULL,NULL,NULL,'<p>With a commitment to quality content for the Craft-community.</p>\n<p><a href=\"#\">privacy policy</a></p>'),(46,46,1,'footer','2023-12-04 16:31:06','2023-12-04 16:31:06','daf8f58e-b16f-4fa0-a799-a1e13ceb4dd5',NULL,NULL,NULL,NULL,'<p>With a commitment to quality content for the Craft-community.</p>\n<p>hello </p>\n<p><a href=\"#\">privacy policy</a></p>'),(48,48,1,'footer','2023-12-04 16:31:34','2023-12-04 16:31:34','5e31b659-388d-4413-922c-60201f610154',NULL,NULL,NULL,NULL,'<p>With a commitment to quality content for the Craft-community.</p>\n<p><a href=\"#\">privacy policy</a></p>'),(50,50,1,'footer','2023-12-04 16:33:05','2023-12-04 16:33:05','ae4fecfe-cec7-41da-b80f-b77ec45dfd4c',NULL,NULL,NULL,NULL,'<p>With a commitment to quality content for the Craft-community.</p>\n<p><a href=\"#\">privacy policy</a> | <a title=\"google\" href=\"http://www.google.be\">google</a></p>'),(52,52,1,'footer','2023-12-04 16:33:35','2023-12-04 16:33:35','f19b00f3-8ea1-497b-ab1a-f7acbd2d7bef',NULL,NULL,NULL,NULL,'<p>With a commitment to quality content for the Craft-community.</p>\n<p><a href=\"#\">privacy policy</a></p>'),(53,53,1,'header title','2023-12-04 16:38:20','2023-12-04 16:42:35','2fd121a8-1671-4708-b47f-2b9b82bc9f35',NULL,NULL,NULL,NULL,'<h1>Latest <span class=\"highlight\">Craft CMS</span> updates</h1>'),(54,54,1,'header title','2023-12-04 16:38:20','2023-12-04 16:38:20','7e47a5dc-774b-46d9-bb1f-bf21ce0c13e9',NULL,NULL,NULL,NULL,NULL),(55,55,1,'header title','2023-12-04 16:38:20','2023-12-04 16:38:20','a300bccd-43bb-4a00-b96f-3df30b3c8a52',NULL,NULL,NULL,NULL,NULL),(56,56,1,'header title','2023-12-04 16:39:46','2023-12-04 16:39:46','d4e9109c-7396-4fc7-b158-d08a8f375cb4',NULL,NULL,NULL,NULL,NULL),(58,58,1,'header title','2023-12-04 16:41:35','2023-12-04 16:41:35','e1daa981-9239-4e83-8542-91bf358c4518',NULL,NULL,NULL,NULL,'<h1>Latest <span class=\"highlight\">Craft CMS</span> updates</h1>\n<h2>for all your craft needs!</h2>'),(60,60,1,'header title','2023-12-04 16:42:35','2023-12-04 16:42:35','df8c0581-a432-4fce-b5b3-001144477871',NULL,NULL,NULL,NULL,'<h1>Latest <span class=\"highlight\">Craft CMS</span> updates</h1>'),(61,61,1,'About Us','2023-12-04 16:45:25','2023-12-04 16:54:11','9a65f012-5b5b-43dc-b468-7f35f9243cb0',NULL,NULL,NULL,NULL,'<h1 style=\"text-align:center;\">we are a team of developer dedicated to CraftCMS</h1>\n<p style=\"text-align:center;\">We hope you are just as dedicated as us. If not you can find us at:</p>\n<p style=\"text-align:center;\">Raghenoplein 22bis, 2800 Mechelen</p>'),(62,62,1,'About Us','2023-12-04 16:45:25','2023-12-04 16:45:25','ca4691ac-dc37-48d1-b659-61677f691849',NULL,NULL,NULL,NULL,NULL),(63,63,1,'About Us','2023-12-04 16:45:25','2023-12-04 16:45:25','74370b0e-eda6-4a53-aed9-6fdc436972cd',NULL,NULL,NULL,NULL,NULL),(64,64,1,'About Us','2023-12-04 16:45:37','2023-12-04 16:45:37','090ebd43-6231-4647-af26-3de6759bae0c',NULL,NULL,NULL,NULL,NULL),(65,65,1,'About Us','2023-12-04 16:48:35','2023-12-04 16:48:35','af8269a8-b92a-4b33-81c2-662f571ccb98',NULL,NULL,NULL,NULL,NULL),(66,66,1,'About Us','2023-12-04 16:48:35','2023-12-04 16:48:35','8ca93c16-318a-406b-84e7-83de67087f5c',NULL,NULL,NULL,NULL,NULL),(68,68,1,'About Us','2023-12-04 16:52:24','2023-12-04 16:52:24','151b72ce-eb41-4da5-8626-6d09df96f84e',NULL,NULL,NULL,NULL,'<h1>we are a team of developer dedicated to CraftCMS</h1>\n<p>We hope you are just as dedicated as us. If not you can find us at:</p>\n<p>Raghenoplein 22bis, 2800 Mechelen</p>'),(70,70,1,'About Us','2023-12-04 16:54:11','2023-12-04 16:54:11','06094c4c-1a40-42b4-bacd-658f11936fa6',NULL,NULL,NULL,NULL,'<h1 style=\"text-align:center;\">we are a team of developer dedicated to CraftCMS</h1>\n<p style=\"text-align:center;\">We hope you are just as dedicated as us. If not you can find us at:</p>\n<p style=\"text-align:center;\">Raghenoplein 22bis, 2800 Mechelen</p>');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_znigcgfbimqhtiivfdaonipdydrebtkmhsgg` (`userId`),
  CONSTRAINT `fk_znigcgfbimqhtiivfdaonipdydrebtkmhsgg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hjaaqtaovmayxcisahxxejfdltfisruwhifu` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_lxphdozigmrcvyssfjhysngjjzsdszpzeyol` (`creatorId`,`provisional`),
  KEY `idx_uoxgkthhusupdursradkqumlnremekzaozdz` (`saved`),
  KEY `fk_qictupythawywwmupfotvwjmwedlegyfuzds` (`canonicalId`),
  CONSTRAINT `fk_gzvmglhwwqkxuzqfynslnoqgmwhibhpbnnws` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qictupythawywwmupfotvwjmwedlegyfuzds` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_wapmvfaeguggojciijjromgalqxnchyrifxi` (`elementId`,`timestamp`,`userId`),
  KEY `fk_xetybxededklnvgiclcnmjlvtayfmgnixcwt` (`userId`),
  KEY `fk_smwhpmpqydcirbhxshdnwxfkpzrvryszxvkj` (`siteId`),
  KEY `fk_yusvohrrnvxflvisklrgsfysgdkmekduuxbb` (`draftId`),
  CONSTRAINT `fk_smwhpmpqydcirbhxshdnwxfkpzrvryszxvkj` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xetybxededklnvgiclcnmjlvtayfmgnixcwt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yrucpgxfvelthinegqmmjosiamnjkzlltwnd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yusvohrrnvxflvisklrgsfysgdkmekduuxbb` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (2,1,1,NULL,'edit','2023-12-04 14:39:38'),(2,1,1,NULL,'save','2023-12-04 14:39:39'),(6,1,1,NULL,'edit','2023-12-04 14:39:00'),(6,1,1,NULL,'save','2023-12-04 14:39:00'),(10,1,1,NULL,'edit','2023-12-04 14:39:15'),(10,1,1,NULL,'save','2023-12-04 14:39:16'),(14,1,1,NULL,'edit','2023-12-04 14:38:50'),(14,1,1,NULL,'save','2023-12-04 14:38:51'),(30,1,1,NULL,'save','2023-12-04 15:57:34'),(33,1,1,NULL,'save','2023-12-04 16:00:19'),(36,1,1,NULL,'save','2023-12-04 16:02:18'),(39,1,1,NULL,'edit','2023-12-04 16:33:27'),(39,1,1,NULL,'save','2023-12-04 16:33:35'),(53,1,1,NULL,'edit','2023-12-04 16:42:35'),(53,1,1,NULL,'save','2023-12-04 16:42:35'),(61,1,1,NULL,'edit','2023-12-04 16:54:11'),(61,1,1,NULL,'save','2023-12-04 16:54:11');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ywmddtlwswdpbbtbprlfghcmwmgufrbcpsqv` (`dateDeleted`),
  KEY `idx_lfvstzcovqdjcrylktyzfsvfjvghqoozrrkf` (`fieldLayoutId`),
  KEY `idx_ckphfwlrbwfwaphrkawjxlagfdehismzphlr` (`type`),
  KEY `idx_ypfsdmyklddqzyaqztoyjgjklkqtgapxlgtw` (`enabled`),
  KEY `idx_pzuaewhrldsccmrytgdpwnnxyounvwvdvjwz` (`canonicalId`),
  KEY `idx_iqcgrczxnrksgxmczceswkustyaqbocwkhhp` (`archived`,`dateCreated`),
  KEY `idx_fjqcghxojfksuauuigirxerrbfhvsqivqegg` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_qxqzektnucyadwgmsrmbjzagkrbeqalwgsjn` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_rnwrbddlmhjwjudbuohgukezcaxbuvadebxp` (`draftId`),
  KEY `fk_ivxxpoktrmazowiatkhlqodmnftjuroqbnuk` (`revisionId`),
  CONSTRAINT `fk_ivxxpoktrmazowiatkhlqodmnftjuroqbnuk` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rnwrbddlmhjwjudbuohgukezcaxbuvadebxp` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uliuawquveepokkebzuashuunvcfrgbvaxyk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yjvzrlasriptxyokyuusmzotpishtcxwagcw` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2023-12-04 13:07:51','2023-12-08 14:46:27',NULL,NULL,'2953b477-2032-4875-bbb9-61fa66e3ac84'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-12-04 13:43:45','2023-12-04 14:39:38',NULL,NULL,'5587fe92-bc77-447f-aa6d-91c54e6f2012'),(3,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 13:49:00','2023-12-04 13:49:00',NULL,NULL,'f862c86e-97c2-44b8-b824-7783f1d49f24'),(4,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 13:49:05','2023-12-04 13:49:05',NULL,NULL,'ce74028c-2c12-4b5c-b9ec-471d72035276'),(5,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2023-12-04 13:49:55','2023-12-04 13:49:55',NULL,NULL,'f46afe20-dc8b-453b-840a-4c8b0408ecc6'),(6,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-12-04 13:50:29','2023-12-04 14:39:00',NULL,NULL,'f9e9ba7b-4990-4ca7-939c-7789c5a4fc49'),(7,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 13:50:47','2023-12-04 13:50:47',NULL,NULL,'0852ce07-4a97-4899-872f-c96ba3a55cdf'),(8,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 13:50:51','2023-12-04 13:50:51',NULL,NULL,'7ff93a12-34cb-4630-a69f-752925b89a8a'),(9,6,NULL,2,1,'craft\\elements\\Entry',1,0,'2023-12-04 13:51:12','2023-12-04 13:51:12',NULL,NULL,'360b8fc5-9550-4909-90db-90933289786c'),(10,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-12-04 13:51:15','2023-12-04 14:39:15',NULL,NULL,'f06cfec4-adfd-4f63-a1e7-6ee48b791b0d'),(11,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 13:51:30','2023-12-04 13:51:30',NULL,NULL,'fe784bbe-e415-4af1-a716-ab328cd44a9f'),(12,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 13:51:34','2023-12-04 13:51:34',NULL,NULL,'9657b59b-ef5d-49b8-9f83-271255516bc6'),(13,10,NULL,3,1,'craft\\elements\\Entry',1,0,'2023-12-04 13:51:48','2023-12-04 13:51:48',NULL,NULL,'599e1009-3aea-4c58-aac3-0ed3aab38601'),(14,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-12-04 13:51:50','2023-12-04 14:38:51',NULL,NULL,'e3d68bca-ae47-4734-873f-66a2243c4af9'),(15,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 13:52:41','2023-12-04 13:52:41',NULL,NULL,'57ae98d4-9c6f-444e-8078-dae335a17c92'),(16,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 13:52:45','2023-12-04 13:52:45',NULL,NULL,'a0f8a5e3-8a2e-40a8-973d-f1880fb28b0d'),(17,14,NULL,4,1,'craft\\elements\\Entry',1,0,'2023-12-04 13:53:30','2023-12-04 13:53:30',NULL,NULL,'623f2211-7b8f-4e12-b0f9-9b639350e185'),(19,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 14:38:49','2023-12-04 14:38:49',NULL,NULL,'fc5394ac-5d10-48b4-aef2-92d59d90b8af'),(20,14,NULL,5,1,'craft\\elements\\Entry',1,0,'2023-12-04 14:38:51','2023-12-04 14:38:51',NULL,NULL,'dab57d76-6ee0-4e0d-b9ab-abd27a2bc4db'),(22,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 14:38:59','2023-12-04 14:38:59',NULL,NULL,'980c8454-eb4d-472c-99d4-eb5bb72a80bf'),(23,6,NULL,6,1,'craft\\elements\\Entry',1,0,'2023-12-04 14:39:00','2023-12-04 14:39:00',NULL,NULL,'acf03839-b330-467a-97ab-6b4eeb01718e'),(24,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 14:39:12','2023-12-04 14:39:12',NULL,NULL,'00c5d721-5872-41da-a30f-26fe5ecd6b9c'),(26,10,NULL,7,1,'craft\\elements\\Entry',1,0,'2023-12-04 14:39:15','2023-12-04 14:39:15',NULL,NULL,'18931fcf-fa9b-4754-a827-cea3e58b6c46'),(28,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 14:39:37','2023-12-04 14:39:38',NULL,NULL,'75f03cc1-5287-4dc8-b337-d9b94524b7f4'),(29,2,NULL,8,1,'craft\\elements\\Entry',1,0,'2023-12-04 14:39:38','2023-12-04 14:39:39',NULL,NULL,'7b3c224f-280c-4d6f-9f63-9690f01270fa'),(30,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-12-04 15:55:58','2023-12-04 15:57:34',NULL,NULL,'e4657cfc-bd25-4bdd-9dfa-bbe965ec7adb'),(31,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 15:57:30','2023-12-04 15:57:30',NULL,NULL,'9d26eec7-661e-409c-adbd-0e976d3f00c9'),(32,30,NULL,9,3,'craft\\elements\\Entry',1,0,'2023-12-04 15:57:34','2023-12-04 15:57:34',NULL,NULL,'c8d4e84e-1a88-4818-a066-c4d47ef57927'),(33,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-12-04 15:58:25','2023-12-04 16:00:19',NULL,NULL,'c4990841-7432-4591-97e2-10849478ced1'),(34,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 16:00:15','2023-12-04 16:00:16',NULL,NULL,'e69c5213-0448-4671-bf2e-4ce211de0bec'),(35,33,NULL,10,3,'craft\\elements\\Entry',1,0,'2023-12-04 16:00:19','2023-12-04 16:00:19',NULL,NULL,'493b4b64-0621-40f8-93f8-626775c718cc'),(36,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-12-04 16:00:21','2023-12-04 16:02:18',NULL,NULL,'6faf3c71-56f8-420e-b816-ff37d273ef1e'),(37,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2023-12-04 16:02:15','2023-12-04 16:02:16',NULL,NULL,'9e98e4f1-89d8-402f-9d8a-a625a4eca8cc'),(38,36,NULL,11,3,'craft\\elements\\Entry',1,0,'2023-12-04 16:02:18','2023-12-04 16:02:18',NULL,NULL,'f0309819-2976-46f3-a52f-bf0e3bbc2ac0'),(39,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2023-12-04 16:20:03','2023-12-04 16:33:35',NULL,NULL,'e7107319-4bb0-4c5f-8a08-c9c76276f75b'),(40,39,NULL,12,4,'craft\\elements\\Entry',1,0,'2023-12-04 16:20:03','2023-12-04 16:20:03',NULL,NULL,'7f948428-b30f-4d1c-87c1-9160f39b8492'),(41,39,NULL,13,4,'craft\\elements\\Entry',1,0,'2023-12-04 16:20:03','2023-12-04 16:20:03',NULL,NULL,'d86e79bd-fd78-445a-b7b8-bde4d6f6a92d'),(42,39,NULL,14,4,'craft\\elements\\Entry',1,0,'2023-12-04 16:26:17','2023-12-04 16:26:17',NULL,NULL,'e6a48dc3-b9c8-4e66-82aa-d474cd2ccd01'),(44,39,NULL,15,4,'craft\\elements\\Entry',1,0,'2023-12-04 16:28:14','2023-12-04 16:28:14',NULL,NULL,'2cc782ac-fea9-4118-99e5-f65becb2ebf4'),(46,39,NULL,16,4,'craft\\elements\\Entry',1,0,'2023-12-04 16:31:06','2023-12-04 16:31:06',NULL,NULL,'f570ac91-52d0-410a-bf79-ddb34ac55f5a'),(48,39,NULL,17,4,'craft\\elements\\Entry',1,0,'2023-12-04 16:31:34','2023-12-04 16:31:34',NULL,NULL,'df611aac-5662-4588-bdbd-df169b95e4d1'),(50,39,NULL,18,4,'craft\\elements\\Entry',1,0,'2023-12-04 16:33:05','2023-12-04 16:33:05',NULL,NULL,'f1cb6926-6f53-4be0-a5d6-e35fb8cc4bbb'),(52,39,NULL,19,4,'craft\\elements\\Entry',1,0,'2023-12-04 16:33:35','2023-12-04 16:33:35',NULL,NULL,'3ebbfcb5-4029-46c4-b238-f8fcae66eee8'),(53,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2023-12-04 16:38:20','2023-12-04 16:42:35',NULL,NULL,'f3983005-2f56-4358-9937-c05c66d2edea'),(54,53,NULL,20,5,'craft\\elements\\Entry',1,0,'2023-12-04 16:38:20','2023-12-04 16:38:20',NULL,NULL,'0429baa5-f7dc-4b57-92f8-07ff1e04fe5b'),(55,53,NULL,21,5,'craft\\elements\\Entry',1,0,'2023-12-04 16:38:20','2023-12-04 16:38:20',NULL,NULL,'e1ba9925-32e3-49e2-bb72-4f2bc466c2d2'),(56,53,NULL,22,5,'craft\\elements\\Entry',1,0,'2023-12-04 16:39:46','2023-12-04 16:39:46',NULL,NULL,'f18ee33a-fcb7-46bc-b5f6-7c51fa3925f4'),(58,53,NULL,23,5,'craft\\elements\\Entry',1,0,'2023-12-04 16:41:35','2023-12-04 16:41:35',NULL,NULL,'743794b7-6f30-42af-997c-d6cbc3d725ef'),(60,53,NULL,24,5,'craft\\elements\\Entry',1,0,'2023-12-04 16:42:35','2023-12-04 16:42:35',NULL,NULL,'55684c03-f20e-447a-8fcc-69fc452e5f78'),(61,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2023-12-04 16:45:25','2023-12-04 16:54:11',NULL,NULL,'f8f25289-e340-4bf5-857d-db0e3348f0d5'),(62,61,NULL,25,6,'craft\\elements\\Entry',1,0,'2023-12-04 16:45:25','2023-12-04 16:45:25',NULL,NULL,'65167bc7-200f-4917-8990-31edc925bd45'),(63,61,NULL,26,6,'craft\\elements\\Entry',1,0,'2023-12-04 16:45:25','2023-12-04 16:45:25',NULL,NULL,'ee255f98-c009-4bb7-83c7-cac136ed1152'),(64,61,NULL,27,6,'craft\\elements\\Entry',1,0,'2023-12-04 16:45:36','2023-12-04 16:45:37',NULL,NULL,'0e6fa642-f92e-4d95-9203-c5deccd5b5d8'),(65,61,NULL,28,6,'craft\\elements\\Entry',1,0,'2023-12-04 16:48:35','2023-12-04 16:48:35',NULL,NULL,'cc1451bf-8329-429f-a517-19bde53e2ac2'),(66,61,NULL,29,6,'craft\\elements\\Entry',1,0,'2023-12-04 16:48:35','2023-12-04 16:48:35',NULL,NULL,'358720a3-688e-43eb-99e1-0694f3ad01d1'),(68,61,NULL,30,6,'craft\\elements\\Entry',1,0,'2023-12-04 16:52:24','2023-12-04 16:52:24',NULL,NULL,'9bc1ce76-6bc7-4277-87ec-15fa31c64276'),(70,61,NULL,31,6,'craft\\elements\\Entry',1,0,'2023-12-04 16:54:11','2023-12-04 16:54:11',NULL,NULL,'33d83161-dd1d-430a-9740-4a6dfdf0ef8f');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rohpgkgepvdlzgdecvtakpkslkoswmxovusj` (`elementId`,`siteId`),
  KEY `idx_nhxtsdrroyogolvlnqosqsutnctfprohwkng` (`siteId`),
  KEY `idx_ptuilwwjiyxaokrokxnfunyndbpufwobygjk` (`slug`,`siteId`),
  KEY `idx_atxkyxdjiiaxklfqzpbcvljsmzbmscsrhzmv` (`enabled`),
  KEY `idx_kmymvkrducdirkibrcnavhxmcdbtciirhyfm` (`uri`,`siteId`),
  CONSTRAINT `fk_blqvctlwydikhlokatsdeolsllluhuihkcih` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mripjqrtwlzeqovtfgoywrigfmqvzigrvqge` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2023-12-04 13:07:51','2023-12-04 13:07:51','14e97110-24c9-449a-ae9e-d3db79bbcc9b'),(2,2,1,'flashy-article-about-craft-cms','news/flashy-article-about-craft-cms',1,'2023-12-04 13:43:45','2023-12-04 13:43:59','5d7df86d-3ea6-42ce-8c59-a27351d47ad6'),(3,3,1,NULL,NULL,1,'2023-12-04 13:49:00','2023-12-04 13:49:00','fbdfe8ee-1752-488a-a12b-4c5dd0187df6'),(4,4,1,NULL,NULL,1,'2023-12-04 13:49:05','2023-12-04 13:49:05','874abef9-1142-4e83-8bef-d65a5be74a31'),(5,5,1,'flashy-article-about-craft-cms','news/flashy-article-about-craft-cms',1,'2023-12-04 13:49:55','2023-12-04 13:49:55','c3278564-4daf-4aac-9461-1101ea44b2ee'),(6,6,1,'everything-you-need-to-know-about-craftcms','news/everything-you-need-to-know-about-craftcms',1,'2023-12-04 13:50:29','2023-12-04 13:50:43','a94cc43d-58dc-4632-89b9-c16afb805b69'),(7,7,1,NULL,NULL,1,'2023-12-04 13:50:47','2023-12-04 13:50:47','2d8d0608-66e6-4d43-841d-35ecaa6fa208'),(8,8,1,NULL,NULL,1,'2023-12-04 13:50:51','2023-12-04 13:50:51','bdfc945d-5ce4-485a-bde0-4f22e60a0053'),(9,9,1,'everything-you-need-to-know-about-craftcms','news/everything-you-need-to-know-about-craftcms',1,'2023-12-04 13:51:12','2023-12-04 13:51:12','112aec84-c735-4ea5-8e16-61d77dc91f02'),(10,10,1,'craft-cms-vs-drupal-vs-wordpress','news/craft-cms-vs-drupal-vs-wordpress',1,'2023-12-04 13:51:15','2023-12-04 13:51:26','23ec39f2-f26e-4496-94fa-fe59a3c0f7ad'),(11,11,1,NULL,NULL,1,'2023-12-04 13:51:30','2023-12-04 13:51:30','40f39b68-1dd8-4536-acd3-83b4fef20028'),(12,12,1,NULL,NULL,1,'2023-12-04 13:51:34','2023-12-04 13:51:34','de34a12d-b95a-435c-8b6b-b1cdcfb4fac2'),(13,13,1,'craft-cms-vs-drupal-vs-wordpress','news/craft-cms-vs-drupal-vs-wordpress',1,'2023-12-04 13:51:48','2023-12-04 13:51:48','e9741e1d-d8ea-472c-bb1f-c73500c05bec'),(14,14,1,'how-to-improve-craft-cms-performance','news/how-to-improve-craft-cms-performance',1,'2023-12-04 13:51:50','2023-12-04 13:52:31','db7adfd9-b582-42d6-bf7d-8b3bb8a69229'),(15,15,1,NULL,NULL,1,'2023-12-04 13:52:41','2023-12-04 13:52:41','7380e1a4-1f84-4e96-b493-a41e6e557eb3'),(16,16,1,NULL,NULL,1,'2023-12-04 13:52:45','2023-12-04 13:52:45','7d96c342-8d1c-451c-ab47-d8b00d576f23'),(17,17,1,'how-to-improve-craft-cms-performance','news/how-to-improve-craft-cms-performance',1,'2023-12-04 13:53:30','2023-12-04 13:53:30','d1dc2621-945d-46b0-be26-18834bca909b'),(19,19,1,NULL,NULL,1,'2023-12-04 14:38:49','2023-12-04 14:38:49','586907d6-a848-4fe4-9a74-31492119dcc3'),(20,20,1,'how-to-improve-craft-cms-performance','news/how-to-improve-craft-cms-performance',1,'2023-12-04 14:38:51','2023-12-04 14:38:51','f01ade70-d24e-4caa-8865-ecd509034011'),(22,22,1,NULL,NULL,1,'2023-12-04 14:38:59','2023-12-04 14:38:59','2514e60b-1212-4324-81b3-efb549ca3ebf'),(23,23,1,'everything-you-need-to-know-about-craftcms','news/everything-you-need-to-know-about-craftcms',1,'2023-12-04 14:39:00','2023-12-04 14:39:00','67100236-a5e4-4606-b4e9-c4e3656c0ac6'),(24,24,1,NULL,NULL,1,'2023-12-04 14:39:12','2023-12-04 14:39:12','89004642-13a7-4757-82cb-69021bd2ff69'),(26,26,1,'craft-cms-vs-drupal-vs-wordpress','news/craft-cms-vs-drupal-vs-wordpress',1,'2023-12-04 14:39:15','2023-12-04 14:39:15','46e9dc2d-2a73-46a5-8903-8898ff17e145'),(28,28,1,NULL,NULL,1,'2023-12-04 14:39:37','2023-12-04 14:39:37','048d5e21-93d2-414d-868a-80ac745bdf56'),(29,29,1,'flashy-article-about-craft-cms','news/flashy-article-about-craft-cms',1,'2023-12-04 14:39:39','2023-12-04 14:39:39','8d16cc21-84fb-48fd-9345-bf711079252d'),(30,30,1,'cache-igniter-fire-up-your-sites-performance','plugin-reviews/cache-igniter-fire-up-your-sites-performance',1,'2023-12-04 15:55:58','2023-12-04 15:56:51','6097a3ba-08b9-436f-967c-03f8bb7b827f'),(31,31,1,NULL,NULL,1,'2023-12-04 15:57:30','2023-12-04 15:57:30','fc273b86-91d6-4ba1-9740-43e53b3ff93d'),(32,32,1,'cache-igniter-fire-up-your-sites-performance','plugin-reviews/cache-igniter-fire-up-your-sites-performance',1,'2023-12-04 15:57:34','2023-12-04 15:57:34','53c36aef-e922-4f0f-a2df-fc618901e20c'),(33,33,1,'minify-your-html-css-and-js','plugin-reviews/minify-your-html-css-and-js',1,'2023-12-04 15:58:25','2023-12-04 15:59:07','d9560fa8-2320-463a-9d89-c5256e6728d5'),(34,34,1,NULL,NULL,1,'2023-12-04 16:00:15','2023-12-04 16:00:15','9588e71d-6818-4af8-87c5-215838de9523'),(35,35,1,'minify-your-html-css-and-js','plugin-reviews/minify-your-html-css-and-js',1,'2023-12-04 16:00:19','2023-12-04 16:00:19','0b5be97a-1782-41ae-aeeb-10001f42bb2c'),(36,36,1,'sprig-reactive-components-for-twig','plugin-reviews/sprig-reactive-components-for-twig',1,'2023-12-04 16:00:21','2023-12-04 16:01:38','e95040a5-cbb0-4645-b649-a7428689a7c8'),(37,37,1,NULL,NULL,1,'2023-12-04 16:02:15','2023-12-04 16:02:15','37b4dcb9-9467-42c4-9858-ae1516dd652b'),(38,38,1,'sprig-reactive-components-for-twig','plugin-reviews/sprig-reactive-components-for-twig',1,'2023-12-04 16:02:18','2023-12-04 16:02:18','7a236737-9100-42cc-98a3-4bc43ebc5c90'),(39,39,1,'footer','footer',1,'2023-12-04 16:20:03','2023-12-04 16:20:03','a2f636ac-4e5f-4544-a52b-6e4761aa5582'),(40,40,1,'footer','footer',1,'2023-12-04 16:20:03','2023-12-04 16:20:03','b211e7fc-a34e-4e06-821b-b40206c9aa56'),(41,41,1,'footer','footer',1,'2023-12-04 16:20:03','2023-12-04 16:20:03','cf4c0541-0370-425e-a2e8-43240a5b4120'),(42,42,1,'footer','footer',1,'2023-12-04 16:26:17','2023-12-04 16:26:17','53ff3014-d6bc-4b9e-9777-ce1b6c8958a9'),(44,44,1,'footer','footer',1,'2023-12-04 16:28:14','2023-12-04 16:28:14','ed70a197-7118-4e9e-8aae-5447fd286bc0'),(46,46,1,'footer','footer',1,'2023-12-04 16:31:06','2023-12-04 16:31:06','53b8019a-5241-4d8e-81ea-f882fa31fa04'),(48,48,1,'footer','footer',1,'2023-12-04 16:31:34','2023-12-04 16:31:34','bab69cfa-6b60-4956-b2f4-cb22f1d4f5bc'),(50,50,1,'footer','footer',1,'2023-12-04 16:33:05','2023-12-04 16:33:05','86140a01-4ab3-4a51-bcec-22e6c623d706'),(52,52,1,'footer','footer',1,'2023-12-04 16:33:35','2023-12-04 16:33:35','a0152953-105c-4e28-8374-3c56dfb3fbd7'),(53,53,1,'header-title','header-title',1,'2023-12-04 16:38:20','2023-12-04 16:38:20','a6367de5-3082-441d-a25a-a017b94ac67f'),(54,54,1,'header-title','header-title',1,'2023-12-04 16:38:20','2023-12-04 16:38:20','22b2c8ae-afed-45fe-866d-49ec304ad6e7'),(55,55,1,'header-title','header-title',1,'2023-12-04 16:38:20','2023-12-04 16:38:20','4a7814d1-3bcf-417d-9184-4b46b4be956a'),(56,56,1,'header-title','header-title',1,'2023-12-04 16:39:46','2023-12-04 16:39:46','b78afbc6-49f2-4818-91a2-b9ccdaa04ab0'),(58,58,1,'header-title','header-title',1,'2023-12-04 16:41:35','2023-12-04 16:41:35','636622f1-b92e-433c-9473-4b251fd81955'),(60,60,1,'header-title','header-title',1,'2023-12-04 16:42:35','2023-12-04 16:42:35','a8b1b40c-09f3-4c46-8684-478e99ad964b'),(61,61,1,'about-us','about-us',1,'2023-12-04 16:45:25','2023-12-04 16:45:25','adf401ae-52e5-469a-b11e-c2f973bdb954'),(62,62,1,'about-us','about-us',1,'2023-12-04 16:45:25','2023-12-04 16:45:25','1b49c0b9-b2a4-43fd-a33f-b9a78522b3c2'),(63,63,1,'about-us','about-us',1,'2023-12-04 16:45:25','2023-12-04 16:45:25','f12d3a44-5784-4abb-b1a0-5db312779426'),(64,64,1,'about-us','about-us',1,'2023-12-04 16:45:37','2023-12-04 16:45:37','a63726b5-e1e8-4384-8585-b39c2a60014e'),(65,65,1,'about-us','about-us',1,'2023-12-04 16:48:35','2023-12-04 16:48:35','f057ccf9-8011-44df-b2ad-44863d8c5f2b'),(66,66,1,'about-us','about-us',1,'2023-12-04 16:48:35','2023-12-04 16:48:35','654ac586-4859-47ce-aeec-f89cbff26d24'),(68,68,1,'about-us','about-us',1,'2023-12-04 16:52:24','2023-12-04 16:52:24','b0978166-b68a-46e4-8ceb-8dae45ac49a6'),(70,70,1,'about-us','about-us',1,'2023-12-04 16:54:11','2023-12-04 16:54:11','a9495e6d-c7f1-47be-be91-7d17dbeaae36');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mafmriaymzdwdrhhorgwvpfnxlppgivirzof` (`postDate`),
  KEY `idx_lrxiatfdhkwwdworkcfzgsdchhnjzggjjcnp` (`expiryDate`),
  KEY `idx_hyoynapizocsyzbjxviziaplnvqxsqbnqxhr` (`authorId`),
  KEY `idx_wlfhxdztplhbdxoliylruqnvmxisiuegldxm` (`sectionId`),
  KEY `idx_zvzgdohnetxylfbrlmhficznwtsunfclcqft` (`typeId`),
  KEY `fk_uhtvngzrqbqyfwkxxjtpcxuvhrsmzkwsmhoo` (`parentId`),
  CONSTRAINT `fk_ddlcqjxuqktritctyjirrcaqmarmfqlvwzbd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ejrhkomqicufrypgjpchmpyiyewrenyqaaew` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hqfimprohpwagvcjwbjmweyofqpjrxazyqsq` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uhtvngzrqbqyfwkxxjtpcxuvhrsmzkwsmhoo` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ytgdnodibnsgafogxsonjnewcjrjlfojprzd` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,1,1,'2023-12-04 13:49:00',NULL,NULL,'2023-12-04 13:43:45','2023-12-04 13:49:55'),(5,1,NULL,1,1,'2023-12-04 13:49:00',NULL,NULL,'2023-12-04 13:49:55','2023-12-04 13:49:55'),(6,1,NULL,1,1,'2023-12-04 13:51:00',NULL,NULL,'2023-12-04 13:50:29','2023-12-04 13:51:12'),(9,1,NULL,1,1,'2023-12-04 13:51:00',NULL,NULL,'2023-12-04 13:51:12','2023-12-04 13:51:12'),(10,1,NULL,1,1,'2023-12-04 13:51:00',NULL,NULL,'2023-12-04 13:51:15','2023-12-04 13:51:48'),(13,1,NULL,1,1,'2023-12-04 13:51:00',NULL,NULL,'2023-12-04 13:51:48','2023-12-04 13:51:48'),(14,1,NULL,1,1,'2023-12-04 13:53:00',NULL,NULL,'2023-12-04 13:51:50','2023-12-04 13:53:29'),(17,1,NULL,1,1,'2023-12-04 13:53:00',NULL,NULL,'2023-12-04 13:53:30','2023-12-04 13:53:30'),(20,1,NULL,1,1,'2023-12-04 13:53:00',NULL,NULL,'2023-12-04 14:38:51','2023-12-04 14:38:51'),(23,1,NULL,1,1,'2023-12-04 13:51:00',NULL,NULL,'2023-12-04 14:39:00','2023-12-04 14:39:00'),(26,1,NULL,1,1,'2023-12-04 13:51:00',NULL,NULL,'2023-12-04 14:39:15','2023-12-04 14:39:15'),(29,1,NULL,1,1,'2023-12-04 13:49:00',NULL,NULL,'2023-12-04 14:39:39','2023-12-04 14:39:39'),(30,2,NULL,2,1,'2023-12-04 15:57:00',NULL,NULL,'2023-12-04 15:55:58','2023-12-04 15:57:34'),(32,2,NULL,2,1,'2023-12-04 15:57:00',NULL,NULL,'2023-12-04 15:57:34','2023-12-04 15:57:34'),(33,2,NULL,2,1,'2023-12-04 16:00:00',NULL,NULL,'2023-12-04 15:58:25','2023-12-04 16:00:19'),(35,2,NULL,2,1,'2023-12-04 16:00:00',NULL,NULL,'2023-12-04 16:00:19','2023-12-04 16:00:19'),(36,2,NULL,2,1,'2023-12-04 16:02:00',NULL,NULL,'2023-12-04 16:00:21','2023-12-04 16:02:18'),(38,2,NULL,2,1,'2023-12-04 16:02:00',NULL,NULL,'2023-12-04 16:02:18','2023-12-04 16:02:18'),(39,3,NULL,3,NULL,'2023-12-04 16:20:00',NULL,NULL,'2023-12-04 16:20:03','2023-12-04 16:20:03'),(40,3,NULL,3,NULL,'2023-12-04 16:20:00',NULL,NULL,'2023-12-04 16:20:03','2023-12-04 16:20:03'),(41,3,NULL,3,NULL,'2023-12-04 16:20:00',NULL,NULL,'2023-12-04 16:20:03','2023-12-04 16:20:03'),(42,3,NULL,3,NULL,'2023-12-04 16:20:00',NULL,NULL,'2023-12-04 16:26:17','2023-12-04 16:26:17'),(44,3,NULL,3,NULL,'2023-12-04 16:20:00',NULL,NULL,'2023-12-04 16:28:14','2023-12-04 16:28:14'),(46,3,NULL,3,NULL,'2023-12-04 16:20:00',NULL,NULL,'2023-12-04 16:31:06','2023-12-04 16:31:06'),(48,3,NULL,3,NULL,'2023-12-04 16:20:00',NULL,NULL,'2023-12-04 16:31:34','2023-12-04 16:31:34'),(50,3,NULL,3,NULL,'2023-12-04 16:20:00',NULL,NULL,'2023-12-04 16:33:05','2023-12-04 16:33:05'),(52,3,NULL,3,NULL,'2023-12-04 16:20:00',NULL,NULL,'2023-12-04 16:33:35','2023-12-04 16:33:35'),(53,4,NULL,4,NULL,'2023-12-04 16:38:00',NULL,NULL,'2023-12-04 16:38:20','2023-12-04 16:38:20'),(54,4,NULL,4,NULL,'2023-12-04 16:38:00',NULL,NULL,'2023-12-04 16:38:20','2023-12-04 16:38:20'),(55,4,NULL,4,NULL,'2023-12-04 16:38:00',NULL,NULL,'2023-12-04 16:38:20','2023-12-04 16:38:20'),(56,4,NULL,4,NULL,'2023-12-04 16:38:00',NULL,NULL,'2023-12-04 16:39:46','2023-12-04 16:39:46'),(58,4,NULL,4,NULL,'2023-12-04 16:38:00',NULL,NULL,'2023-12-04 16:41:35','2023-12-04 16:41:35'),(60,4,NULL,4,NULL,'2023-12-04 16:38:00',NULL,NULL,'2023-12-04 16:42:35','2023-12-04 16:42:35'),(61,5,NULL,5,NULL,'2023-12-04 16:45:00',NULL,NULL,'2023-12-04 16:45:25','2023-12-04 16:45:25'),(62,5,NULL,5,NULL,'2023-12-04 16:45:00',NULL,NULL,'2023-12-04 16:45:25','2023-12-04 16:45:25'),(63,5,NULL,5,NULL,'2023-12-04 16:45:00',NULL,NULL,'2023-12-04 16:45:25','2023-12-04 16:45:25'),(64,5,NULL,5,NULL,'2023-12-04 16:45:00',NULL,NULL,'2023-12-04 16:45:37','2023-12-04 16:45:37'),(65,5,NULL,5,NULL,'2023-12-04 16:45:00',NULL,NULL,'2023-12-04 16:48:35','2023-12-04 16:48:35'),(66,5,NULL,5,NULL,'2023-12-04 16:45:00',NULL,NULL,'2023-12-04 16:48:35','2023-12-04 16:48:35'),(68,5,NULL,5,NULL,'2023-12-04 16:45:00',NULL,NULL,'2023-12-04 16:52:24','2023-12-04 16:52:24'),(70,5,NULL,5,NULL,'2023-12-04 16:45:00',NULL,NULL,'2023-12-04 16:54:11','2023-12-04 16:54:11');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kovqcuuvrlmkcohlvkfgljywcjvpulrmjqyt` (`name`,`sectionId`),
  KEY `idx_ivfvyhjtlylqsdgiqiswsxvpchnrtrwxgvej` (`handle`,`sectionId`),
  KEY `idx_vnqyozrkfgjptanybddegvofnqfkyamxisdz` (`sectionId`),
  KEY `idx_llcldpiocopfuftmpdjtcpyksdqsrtnpfijk` (`fieldLayoutId`),
  KEY `idx_ztlhnynxyhigsrhvjqxgzvkzasqhucoggkfb` (`dateDeleted`),
  CONSTRAINT `fk_nvkfxadawpifcxuszygozbeckyxodcnpmxtt` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zsjdnunrsaqjbvrbpzhjkxifgkdecejtvhln` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,1,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2023-12-04 13:25:38','2023-12-04 13:25:38',NULL,'3d20e2e1-db9a-4c48-87ea-da43f742096b'),(2,2,3,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2023-12-04 15:50:19','2023-12-04 15:50:19',NULL,'c7901917-c90e-418e-83ff-0cfbab9fdac0'),(3,3,4,'footer','footer',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2023-12-04 16:20:03','2023-12-04 16:20:03',NULL,'e4b12178-c53b-4272-ac65-501a0d084bcd'),(4,4,5,'header title','headerTitle',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2023-12-04 16:38:20','2023-12-04 16:38:20',NULL,'cbf49ce7-fba8-499b-a0fc-6e39468730c6'),(5,5,6,'About Us','aboutUs',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2023-12-04 16:45:25','2023-12-04 16:45:25',NULL,'2a4f59e5-acf8-4fc7-806a-462bb7563eac');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eeqlcxvwtvcgpwyxvwnlajnmkiuawmuvwbck` (`name`),
  KEY `idx_tyftwewdhwwfvcymujykoddgguukmgsutvxq` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES (1,'Common','2023-12-04 13:07:51','2023-12-04 13:07:51',NULL,'784b6530-b0a2-46f1-a5cc-008816f6ad32');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ngfajjfddvaeznepxaktjgdoggtzvqeyiswp` (`layoutId`,`fieldId`),
  KEY `idx_rvfqwfomgecpdcsirokzjjmbamudggzgscom` (`sortOrder`),
  KEY `idx_wdqscrkvygptoptmyfpnsutqalclapwmmecy` (`tabId`),
  KEY `idx_ppcokyfhpxbfakcpoduoutsttvvnpsqdzcvw` (`fieldId`),
  CONSTRAINT `fk_fqsgchmhmurzprbodhewkdiuyjdbgngizqtt` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wdxuacarrpjfpkmooeulsuvzfrvuzesaawsc` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xvciptdvhcrfdpiyvcjslzntkopldjccwhdz` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `fieldlayoutfields` VALUES (5,1,4,3,1,1,'2023-12-04 14:36:13','2023-12-04 14:36:13','5e57f896-0e83-45fe-8430-2a9a31c4fd99'),(6,1,4,1,1,2,'2023-12-04 14:36:13','2023-12-04 14:36:13','a7ea25c0-f317-4d61-bea6-fadec974a72e'),(7,1,4,2,1,3,'2023-12-04 14:36:13','2023-12-04 14:36:13','285e7369-1a71-4d6d-86e8-48eed764771b'),(10,3,7,3,1,1,'2023-12-04 15:55:07','2023-12-04 15:55:07','66ff4828-d657-4ede-912d-5085f7d9fbea'),(11,3,7,1,1,2,'2023-12-04 15:55:07','2023-12-04 15:55:07','bdbbdc26-2a5f-48bb-a0ab-3f9de0576327'),(12,3,7,5,1,3,'2023-12-04 15:55:07','2023-12-04 15:55:07','73a40a4b-1dc1-43cd-b505-5a12659640cd'),(13,3,7,6,1,4,'2023-12-04 15:55:07','2023-12-04 15:55:07','e7f83052-64ac-4462-bc06-cee6e810ed50'),(14,4,9,7,1,1,'2023-12-04 16:26:17','2023-12-04 16:26:17','32f673fc-b02c-4a70-9ecb-00040f689095'),(15,5,11,7,0,1,'2023-12-04 16:39:46','2023-12-04 16:39:46','a466d9cf-1b28-48ee-89d4-02e8a0b41c05'),(16,6,13,7,1,1,'2023-12-04 16:45:36','2023-12-04 16:45:36','199bb04a-6a4f-4b20-bf50-2cc6136612ad');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_byptbbnbpjikhtaefwscpvzltzkxibmsdsar` (`dateDeleted`),
  KEY `idx_pdsoistxfcodgcjqomytkdbnxfcvupvksqsm` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2023-12-04 13:25:38','2023-12-04 13:25:38',NULL,'26575e64-8a47-4e27-ae72-46f53880825d'),(2,'craft\\elements\\Asset','2023-12-04 13:35:36','2023-12-04 13:35:36',NULL,'804c1a05-0ef6-4213-bfb2-869337758a87'),(3,'craft\\elements\\Entry','2023-12-04 15:50:19','2023-12-04 15:50:19',NULL,'0d8d105f-94a5-4489-9ad8-93de281b8a28'),(4,'craft\\elements\\Entry','2023-12-04 16:20:03','2023-12-04 16:20:03',NULL,'e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4'),(5,'craft\\elements\\Entry','2023-12-04 16:38:20','2023-12-04 16:38:20',NULL,'f919f605-9920-4bc0-a87c-4523cb2566b0'),(6,'craft\\elements\\Entry','2023-12-04 16:45:25','2023-12-04 16:45:25',NULL,'0a4c6db9-88e2-40b3-b89c-1b1d66abcea4');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tweoqadqlnkcnajqwtfeizjwkpvelgrecckx` (`sortOrder`),
  KEY `idx_hfnpmeceywgrhybauldsshkseduqekjyzjbt` (`layoutId`),
  CONSTRAINT `fk_oyzmupfjolgucjyjtmfghykprdohcvkjdncv` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES (2,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"3cbed65d-e6b8-42af-8582-a5df10f8c3a6\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\",\"attribute\":\"alt\",\"requirable\":true,\"class\":null,\"rows\":null,\"cols\":null,\"name\":null,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"3b73a910-52d9-4ab5-a254-4e3e852720d4\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-12-04 13:35:36','2023-12-04 13:35:36','322464b6-0fee-4876-9731-59d98b6c6334'),(4,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"d6cebffa-ced0-4b87-81ee-88b087f5f4cb\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"ba690d01-c728-4f37-8d40-4577186d471b\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"ce59be17-e13d-420b-99b1-1268579e502d\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"bdb89a85-418b-4838-8444-7da85fb84d68\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"6a3950ce-58b7-4be3-8c15-42f377f723bf\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"7ad37b22-adcb-423c-b462-5035bf96d4a3\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"714c9b9d-857c-412e-b00e-8d001081adb3\"}]',1,'2023-12-04 14:36:13','2023-12-04 14:36:13','69f2d38c-bb3b-412a-9b4c-d061be2a23be'),(7,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"aa602f0a-decd-44b5-aa30-b8a5d92515c2\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"a63959c4-335a-4d43-9f83-cca5ecc10290\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"ce59be17-e13d-420b-99b1-1268579e502d\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"4297dec0-01b2-4eca-8bf6-ca50b23d6cce\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"6a3950ce-58b7-4be3-8c15-42f377f723bf\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"a54e9e80-7ccf-4eab-a61c-7af4f477f12e\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a88d603b-3570-44bf-b52a-1eda34742597\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"1592f9e2-3d23-448f-83ff-066029bc863f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"82e46b3b-d595-48b8-8cb7-e5155bd16e7b\"}]',1,'2023-12-04 15:55:07','2023-12-04 15:55:07','fa7f4462-90e1-4803-970a-585eb3fa12df'),(9,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"ddcaea1d-de36-4568-94ae-d31e44ece84f\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"2a46cd48-5c84-4785-9610-720f11ce03b4\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"2365e01a-20c7-42cd-866f-4e4a79bca25d\"}]',1,'2023-12-04 16:26:17','2023-12-04 16:26:17','20765f3e-54b4-4f12-bfd3-98fef53708da'),(11,5,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"c43c1445-f464-4030-b940-3860611762e8\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"40b20664-95d3-45c6-9096-652f0d154fcc\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"2365e01a-20c7-42cd-866f-4e4a79bca25d\"}]',1,'2023-12-04 16:39:46','2023-12-04 16:39:46','4fd009a8-92e4-4754-a3f0-0b9446e703d4'),(13,6,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"1eca2057-f493-422e-939b-e4734474092d\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"ccdaf57b-80fd-472b-9957-ae89c6bb3669\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"2365e01a-20c7-42cd-866f-4e4a79bca25d\"}]',1,'2023-12-04 16:45:36','2023-12-04 16:45:36','7bcc3910-2c32-4281-8378-0f24376e962f');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sgorwhbyvsklrqohwuwzzatgxitjgyhtmunu` (`handle`,`context`),
  KEY `idx_vkdtkpbzketqqppxehnetymyrrobkfrjfoju` (`groupId`),
  KEY `idx_pfwbbqsxkvzphprypwsqrtqzlgcfotpatwok` (`context`),
  CONSTRAINT `fk_byjhllmabucmaoavbbbvcrurkttfltoimnwr` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,1,'intro text','introText','global','yprwwwti',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":400,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-12-04 13:29:51','2023-12-04 13:29:51','6a3950ce-58b7-4be3-8c15-42f377f723bf'),(2,1,'full text','fullText','global','gninfktw',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-12-04 13:30:09','2023-12-04 13:30:09','714c9b9d-857c-412e-b00e-8d001081adb3'),(3,1,'banner image','bannerImage','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:027709b3-b422-4204-9597-c132f25a8567\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"thumbs\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:027709b3-b422-4204-9597-c132f25a8567\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\",\"conditionRules\":[{\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\FileSizeConditionRule\",\"uid\":\"f1b32762-b378-467f-b542-f6bf9fffc145\",\"operator\":\"<\",\"value\":\"100\",\"maxValue\":\"\",\"unit\":\"MB\"}]},\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2023-12-04 13:38:17','2023-12-04 14:38:37','ce59be17-e13d-420b-99b1-1268579e502d'),(5,1,'Rating','rating','global','strxivmx',NULL,0,'none',NULL,'craft\\fields\\Number','{\"decimals\":0,\"defaultValue\":null,\"max\":5,\"min\":0,\"prefix\":null,\"previewCurrency\":null,\"previewFormat\":\"decimal\",\"size\":null,\"suffix\":null}','2023-12-04 15:53:06','2023-12-04 16:08:13','a88d603b-3570-44bf-b52a-1eda34742597'),(6,1,'store url','storeUrl','global','kztiozrj',NULL,0,'none',NULL,'craft\\fields\\Url','{\"maxLength\":255,\"types\":[\"url\"]}','2023-12-04 15:54:16','2023-12-04 15:54:16','82e46b3b-d595-48b8-8cb7-e5155bd16e7b'),(7,1,'rich text','richText','global','xnzochyb',NULL,0,'none',NULL,'abmat\\tinymce\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"columnType\":\"text\",\"purifierConfig\":\"Default.json\",\"purifyHtml\":true,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"tinymceConfig\":\"Default.json\"}','2023-12-04 16:25:50','2023-12-04 16:25:50','2365e01a-20c7-42cd-866f-4e4a79bca25d');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gkrtfgwbsmapsulaiznhnzbgmqcbtvbvtskg` (`name`),
  KEY `idx_ukinzzgpeptalxqrgcchzsqmrdcuismmupnx` (`handle`),
  KEY `idx_hkmkahdvaidrdceojwsypcavgqvazncffnyy` (`fieldLayoutId`),
  KEY `idx_sisyeuzmtbkvtssmxzytesoayhvydtpppkxt` (`sortOrder`),
  CONSTRAINT `fk_evsoguuprjbxtyoshmrdruxhadoefxlescfo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hgbpntpltaiyjgetjupkoimnimmpnjufxfbi` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bwsqfnrfpevsigibevikxiiekpttnzjwyimk` (`accessToken`),
  UNIQUE KEY `idx_fakctixmzadyfihaasooekvnoliutykibqik` (`name`),
  KEY `fk_tplektakxtswaoxnxkmzmjatjbxcsiwikukx` (`schemaId`),
  CONSTRAINT `fk_tplektakxtswaoxnxkmzmjatjbxcsiwikukx` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_weazfkzomtmkgxwnkzdpazsvzptsifapyksv` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
INSERT INTO `imagetransformindex` VALUES (1,3,'craft\\imagetransforms\\ImageTransformer','banner1.jpg',NULL,'_120x48_crop_center-center_none',1,0,0,'2023-12-04 13:49:00','2023-12-04 13:49:00','2023-12-04 13:49:00','576706b0-738a-40b5-b015-7601c379b85e'),(2,3,'craft\\imagetransforms\\ImageTransformer','banner1.jpg',NULL,'_240x96_crop_center-center_none',1,0,0,'2023-12-04 13:49:00','2023-12-04 13:49:00','2023-12-04 13:49:00','54f2ad7e-905a-4771-b2f4-6b270469d791'),(3,4,'craft\\imagetransforms\\ImageTransformer','thumb1.jpg',NULL,'_120x90_crop_center-center_none',1,0,0,'2023-12-04 13:49:06','2023-12-04 13:49:06','2023-12-04 13:49:06','ec57036e-41c1-49ad-9ae9-ecb1e198edb0'),(4,4,'craft\\imagetransforms\\ImageTransformer','thumb1.jpg',NULL,'_240x180_crop_center-center_none',1,0,0,'2023-12-04 13:49:06','2023-12-04 13:49:06','2023-12-04 13:49:06','a03b67c8-2f40-4a42-823a-abbb41729ef9'),(5,3,'craft\\imagetransforms\\ImageTransformer','banner1.jpg',NULL,'_34x13_crop_center-center_none',1,0,0,'2023-12-04 13:50:04','2023-12-04 13:50:04','2023-12-04 13:50:04','d4753354-bf65-4b96-a507-63d81940b0c1'),(6,3,'craft\\imagetransforms\\ImageTransformer','banner1.jpg',NULL,'_68x27_crop_center-center_none',1,0,0,'2023-12-04 13:50:04','2023-12-04 13:50:04','2023-12-04 13:50:30','1d14ed9f-7443-4344-a4c5-499919980746'),(7,7,'craft\\imagetransforms\\ImageTransformer','banner2.jpg',NULL,'_120x48_crop_center-center_none',1,0,0,'2023-12-04 13:50:47','2023-12-04 13:50:47','2023-12-04 13:50:47','a39b2932-a764-4996-9692-3b2634ef421e'),(8,7,'craft\\imagetransforms\\ImageTransformer','banner2.jpg',NULL,'_240x96_crop_center-center_none',1,0,0,'2023-12-04 13:50:47','2023-12-04 13:50:47','2023-12-04 13:50:48','9124b91d-936a-48b8-97f9-4db57454a16c'),(9,8,'craft\\imagetransforms\\ImageTransformer','thumb2.jpg',NULL,'_120x90_crop_center-center_none',1,0,0,'2023-12-04 13:50:51','2023-12-04 13:50:51','2023-12-04 13:50:51','584b1f37-c7d4-473f-8020-8dab612784af'),(10,8,'craft\\imagetransforms\\ImageTransformer','thumb2.jpg',NULL,'_240x180_crop_center-center_none',1,0,0,'2023-12-04 13:50:51','2023-12-04 13:50:51','2023-12-04 13:50:51','4eb46828-047f-44f4-bda9-e22d4170e3b6'),(11,7,'craft\\imagetransforms\\ImageTransformer','banner2.jpg',NULL,'_34x13_crop_center-center_none',1,0,0,'2023-12-04 13:51:13','2023-12-04 13:51:13','2023-12-04 13:51:13','b742c2e9-e2ba-4fe5-8fde-105a8f10a4a0'),(12,7,'craft\\imagetransforms\\ImageTransformer','banner2.jpg',NULL,'_68x27_crop_center-center_none',1,0,0,'2023-12-04 13:51:13','2023-12-04 13:51:13','2023-12-04 13:51:13','2e0f099d-6fd8-471b-813f-ae10c71b71a9'),(13,11,'craft\\imagetransforms\\ImageTransformer','banner3.jpg',NULL,'_120x48_crop_center-center_none',1,0,0,'2023-12-04 13:51:31','2023-12-04 13:51:31','2023-12-04 13:51:31','bc686555-4766-45f5-aba3-3bbfc48600cd'),(14,11,'craft\\imagetransforms\\ImageTransformer','banner3.jpg',NULL,'_240x96_crop_center-center_none',1,0,0,'2023-12-04 13:51:31','2023-12-04 13:51:31','2023-12-04 13:51:31','74139941-b2a3-456c-950e-569d0a2c5f77'),(15,12,'craft\\imagetransforms\\ImageTransformer','thumb3.jpg',NULL,'_120x90_crop_center-center_none',1,0,0,'2023-12-04 13:51:34','2023-12-04 13:51:34','2023-12-04 13:51:35','5bdea4cb-bb53-4dec-88ba-2cc5603a431b'),(16,12,'craft\\imagetransforms\\ImageTransformer','thumb3.jpg',NULL,'_240x180_crop_center-center_none',1,0,0,'2023-12-04 13:51:34','2023-12-04 13:51:34','2023-12-04 13:51:35','c3b2c720-0d0c-4696-a597-9c7b2f39ff65'),(17,11,'craft\\imagetransforms\\ImageTransformer','banner3.jpg',NULL,'_34x13_crop_center-center_none',1,0,0,'2023-12-04 13:51:49','2023-12-04 13:51:49','2023-12-04 13:51:49','91333f54-3650-4749-87b3-034d2d5d5633'),(18,11,'craft\\imagetransforms\\ImageTransformer','banner3.jpg',NULL,'_68x27_crop_center-center_none',1,0,0,'2023-12-04 13:51:49','2023-12-04 13:51:49','2023-12-04 13:51:49','60e81e8d-291a-4aae-b539-d9a318633581'),(19,15,'craft\\imagetransforms\\ImageTransformer','banner2_2023-12-04-135241_jnph.jpg',NULL,'_120x48_crop_center-center_none',1,0,0,'2023-12-04 13:52:41','2023-12-04 13:52:41','2023-12-04 13:52:41','08bfd355-49e5-4d6e-9682-a7089b0b0e25'),(20,15,'craft\\imagetransforms\\ImageTransformer','banner2_2023-12-04-135241_jnph.jpg',NULL,'_240x96_crop_center-center_none',1,0,0,'2023-12-04 13:52:41','2023-12-04 13:52:41','2023-12-04 13:52:41','2cbe8abb-256e-461f-bcdd-f0426c36676c'),(21,16,'craft\\imagetransforms\\ImageTransformer','thumb3_2023-12-04-135245_rxoi.jpg',NULL,'_120x90_crop_center-center_none',1,0,0,'2023-12-04 13:52:45','2023-12-04 13:52:45','2023-12-04 13:52:45','64c49e4c-2bd1-499b-8a70-d487617d0bb3'),(22,16,'craft\\imagetransforms\\ImageTransformer','thumb3_2023-12-04-135245_rxoi.jpg',NULL,'_240x180_crop_center-center_none',1,0,0,'2023-12-04 13:52:45','2023-12-04 13:52:45','2023-12-04 13:52:45','39d1e234-78c3-4e45-adf9-e188081b8bee'),(23,15,'craft\\imagetransforms\\ImageTransformer','banner2_2023-12-04-135241_jnph.jpg',NULL,'_34x13_crop_center-center_none',1,0,0,'2023-12-04 13:53:30','2023-12-04 13:53:30','2023-12-04 13:53:30','8691d849-016e-4e07-9643-0ec3f2ebf64e'),(24,15,'craft\\imagetransforms\\ImageTransformer','banner2_2023-12-04-135241_jnph.jpg',NULL,'_68x27_crop_center-center_none',1,0,0,'2023-12-04 13:53:30','2023-12-04 13:53:30','2023-12-04 13:53:30','0bab1156-052b-4ca0-b5b3-e4d67be68abc'),(25,19,'craft\\imagetransforms\\ImageTransformer','luke-chesser-JKUTrJ4vK00-unsplash.jpg',NULL,'_120x80_crop_center-center_none',1,0,0,'2023-12-04 14:38:50','2023-12-04 14:38:50','2023-12-04 14:38:50','4140be37-752d-4324-9e7c-2c33fb7663d2'),(26,19,'craft\\imagetransforms\\ImageTransformer','luke-chesser-JKUTrJ4vK00-unsplash.jpg',NULL,'_240x160_crop_center-center_none',1,0,0,'2023-12-04 14:38:50','2023-12-04 14:38:50','2023-12-04 14:38:51','ed9b7990-5971-42bd-9591-538297ca52b5'),(27,19,'craft\\imagetransforms\\ImageTransformer','luke-chesser-JKUTrJ4vK00-unsplash.jpg',NULL,'_34x22_crop_center-center_none',1,0,0,'2023-12-04 14:38:51','2023-12-04 14:38:51','2023-12-04 14:38:52','8c08a92e-7c66-486b-ac60-11f9f696dcad'),(28,19,'craft\\imagetransforms\\ImageTransformer','luke-chesser-JKUTrJ4vK00-unsplash.jpg',NULL,'_68x45_crop_center-center_none',1,0,0,'2023-12-04 14:38:51','2023-12-04 14:38:51','2023-12-04 14:38:53','9bf2b951-39f9-4631-a18c-d821e8d19720'),(29,22,'craft\\imagetransforms\\ImageTransformer','luca-bravo-9l_326FISzk-unsplash-2.jpg',NULL,'_120x80_crop_center-center_none',1,0,0,'2023-12-04 14:39:00','2023-12-04 14:39:00','2023-12-04 14:39:00','37303fce-27e6-432f-ae5c-1cb931143a85'),(30,22,'craft\\imagetransforms\\ImageTransformer','luca-bravo-9l_326FISzk-unsplash-2.jpg',NULL,'_240x160_crop_center-center_none',1,0,0,'2023-12-04 14:39:00','2023-12-04 14:39:00','2023-12-04 14:39:00','6d4ff333-a097-47c1-a30f-4abca8f29649'),(31,22,'craft\\imagetransforms\\ImageTransformer','luca-bravo-9l_326FISzk-unsplash-2.jpg',NULL,'_34x22_crop_center-center_none',1,0,0,'2023-12-04 14:39:01','2023-12-04 14:39:01','2023-12-04 14:39:01','1e7f4f12-4afa-40a9-89bf-5f28fceb5f07'),(32,22,'craft\\imagetransforms\\ImageTransformer','luca-bravo-9l_326FISzk-unsplash-2.jpg',NULL,'_68x45_crop_center-center_none',1,0,0,'2023-12-04 14:39:01','2023-12-04 14:39:01','2023-12-04 14:39:01','c380d29e-e50a-482f-b1c9-dfeb317f9632'),(33,24,'craft\\imagetransforms\\ImageTransformer','souvik-banerjee-WPrNEM_6dg-unsplash.jpg',NULL,'_120x80_crop_center-center_none',1,0,0,'2023-12-04 14:39:12','2023-12-04 14:39:12','2023-12-04 14:39:12','4ee345df-4173-4610-82f9-6187ed189fa8'),(34,24,'craft\\imagetransforms\\ImageTransformer','souvik-banerjee-WPrNEM_6dg-unsplash.jpg',NULL,'_240x160_crop_center-center_none',1,0,0,'2023-12-04 14:39:12','2023-12-04 14:39:12','2023-12-04 14:39:12','9808e8d3-ed46-4e79-9969-5c091642e2ab'),(35,24,'craft\\imagetransforms\\ImageTransformer','souvik-banerjee-WPrNEM_6dg-unsplash.jpg',NULL,'_34x22_crop_center-center_none',1,0,0,'2023-12-04 14:39:16','2023-12-04 14:39:16','2023-12-04 14:39:17','be257c7e-80b6-408f-9bc4-d04dabb11cd0'),(36,24,'craft\\imagetransforms\\ImageTransformer','souvik-banerjee-WPrNEM_6dg-unsplash.jpg',NULL,'_68x45_crop_center-center_none',1,0,0,'2023-12-04 14:39:16','2023-12-04 14:39:16','2023-12-04 14:39:17','d0578255-bc9f-478d-a3fc-db98dd24839a'),(37,28,'craft\\imagetransforms\\ImageTransformer','ilya-pavlov-OqtafYT5kTw-unsplash.jpg',NULL,'_120x80_crop_center-center_none',1,0,0,'2023-12-04 14:39:38','2023-12-04 14:39:38','2023-12-04 14:39:38','6dee41c7-7566-49fb-91ef-42e66fd63c30'),(38,28,'craft\\imagetransforms\\ImageTransformer','ilya-pavlov-OqtafYT5kTw-unsplash.jpg',NULL,'_240x160_crop_center-center_none',1,0,0,'2023-12-04 14:39:38','2023-12-04 14:39:38','2023-12-04 14:39:39','9a7565bb-470c-40f3-9b88-ae5316b2531f'),(39,28,'craft\\imagetransforms\\ImageTransformer','ilya-pavlov-OqtafYT5kTw-unsplash.jpg',NULL,'_34x22_crop_center-center_none',1,0,0,'2023-12-04 14:39:39','2023-12-04 14:39:39','2023-12-04 14:39:39','2175cc4c-5a80-43e0-b858-390d2421dedf'),(40,28,'craft\\imagetransforms\\ImageTransformer','ilya-pavlov-OqtafYT5kTw-unsplash.jpg',NULL,'_68x45_crop_center-center_none',1,0,0,'2023-12-04 14:39:39','2023-12-04 14:39:39','2023-12-04 14:42:23','aec18faa-6f97-4e41-ae1c-a8352533e536'),(41,19,'craft\\imagetransforms\\ImageTransformer','luke-chesser-JKUTrJ4vK00-unsplash.jpg',NULL,'_banner',1,0,0,'2023-12-04 14:42:23','2023-12-04 14:42:23','2023-12-04 14:42:23','21a194c1-16e4-49fa-a79b-9d4830206947'),(42,19,'craft\\imagetransforms\\ImageTransformer','luke-chesser-JKUTrJ4vK00-unsplash.jpg',NULL,'_thumbnail',1,0,0,'2023-12-04 14:43:09','2023-12-04 14:43:09','2023-12-04 14:43:09','b16f3e77-ee3e-4c8a-a8a0-c9fd08479915'),(43,22,'craft\\imagetransforms\\ImageTransformer','luca-bravo-9l_326FISzk-unsplash-2.jpg',NULL,'_banner',1,0,0,'2023-12-04 14:43:09','2023-12-04 14:43:09','2023-12-04 14:43:11','7477d3c2-08f2-4682-8f42-85d14a8b1df1'),(44,22,'craft\\imagetransforms\\ImageTransformer','luca-bravo-9l_326FISzk-unsplash-2.jpg',NULL,'_thumbnail',1,0,0,'2023-12-04 14:43:09','2023-12-04 14:43:09','2023-12-04 14:43:09','1126acbb-d516-46f6-a47d-d57b99983d87'),(45,24,'craft\\imagetransforms\\ImageTransformer','souvik-banerjee-WPrNEM_6dg-unsplash.jpg',NULL,'_banner',1,0,0,'2023-12-04 14:43:09','2023-12-04 14:43:09','2023-12-04 14:43:11','1f6565b5-602b-422a-b19d-fcf6ce53d940'),(46,24,'craft\\imagetransforms\\ImageTransformer','souvik-banerjee-WPrNEM_6dg-unsplash.jpg',NULL,'_thumbnail',1,0,0,'2023-12-04 14:43:09','2023-12-04 14:43:09','2023-12-04 14:43:09','54552960-93fb-4c1e-9129-423306aa244c'),(47,19,'craft\\imagetransforms\\ImageTransformer','luke-chesser-JKUTrJ4vK00-unsplash.jpg',NULL,'_header',1,0,0,'2023-12-04 14:47:40','2023-12-04 14:47:40','2023-12-04 14:47:40','70c9298c-4874-4f0a-98f6-95424a586ca7'),(48,28,'craft\\imagetransforms\\ImageTransformer','ilya-pavlov-OqtafYT5kTw-unsplash.jpg',NULL,'_banner',1,0,0,'2023-12-04 15:43:21','2023-12-04 15:43:21','2023-12-04 15:43:21','5dbb2b2d-f9aa-4db4-94e2-d8278dbbb24e'),(49,22,'craft\\imagetransforms\\ImageTransformer','luca-bravo-9l_326FISzk-unsplash-2.jpg',NULL,'_header',1,0,0,'2023-12-04 15:44:31','2023-12-04 15:44:31','2023-12-04 15:44:31','d74caa65-6cc9-481d-9192-2d4882c61d4a'),(50,31,'craft\\imagetransforms\\ImageTransformer','ttfb-map-warmed-full.png',NULL,'_120x53_crop_center-center_none',1,0,0,'2023-12-04 15:57:31','2023-12-04 15:57:31','2023-12-04 15:57:31','05dc5f05-7ab7-4397-840f-46e0b3f10987'),(51,31,'craft\\imagetransforms\\ImageTransformer','ttfb-map-warmed-full.png',NULL,'_240x107_crop_center-center_none',1,0,0,'2023-12-04 15:57:31','2023-12-04 15:57:31','2023-12-04 15:57:31','3c0f9068-4d0f-42e4-a88f-907ede324c5b'),(52,31,'craft\\imagetransforms\\ImageTransformer','ttfb-map-warmed-full.png',NULL,'_34x15_crop_center-center_none',1,1,0,'2023-12-04 15:57:34','2023-12-04 15:57:34','2023-12-04 15:57:35','4046af9e-e794-4c81-badc-b2b3ccd26f2d'),(53,31,'craft\\imagetransforms\\ImageTransformer','ttfb-map-warmed-full.png',NULL,'_68x30_crop_center-center_none',1,0,0,'2023-12-04 15:57:34','2023-12-04 15:57:34','2023-12-04 15:57:35','d13b3f1a-b52c-4127-957b-34b26abc4f36'),(54,34,'craft\\imagetransforms\\ImageTransformer','walkator-klMii3cR9iI-unsplash.jpg',NULL,'_90x120_crop_center-center_none',1,0,0,'2023-12-04 16:00:16','2023-12-04 16:00:16','2023-12-04 16:00:17','d500986c-bf47-44ef-b69e-f8075adba26a'),(55,34,'craft\\imagetransforms\\ImageTransformer','walkator-klMii3cR9iI-unsplash.jpg',NULL,'_180x240_crop_center-center_none',1,0,0,'2023-12-04 16:00:16','2023-12-04 16:00:16','2023-12-04 16:00:17','db12bb46-3ecf-47a1-921d-aedf9248aa36'),(56,34,'craft\\imagetransforms\\ImageTransformer','walkator-klMii3cR9iI-unsplash.jpg',NULL,'_25x34_crop_center-center_none',1,0,0,'2023-12-04 16:00:20','2023-12-04 16:00:20','2023-12-04 16:00:20','0780f85c-e1e2-408c-bdac-32c5a65b5d9c'),(57,34,'craft\\imagetransforms\\ImageTransformer','walkator-klMii3cR9iI-unsplash.jpg',NULL,'_51x68_crop_center-center_none',1,0,0,'2023-12-04 16:00:20','2023-12-04 16:00:20','2023-12-04 16:00:21','97af1c5d-6ddf-4100-9f40-8f4566e20e37'),(58,37,'craft\\imagetransforms\\ImageTransformer','sprigcart-preview.png',NULL,'_120x72_crop_center-center_none',1,0,0,'2023-12-04 16:02:16','2023-12-04 16:02:16','2023-12-04 16:02:16','74e18f83-1c24-4dca-adef-839dd0e71c76'),(59,37,'craft\\imagetransforms\\ImageTransformer','sprigcart-preview.png',NULL,'_240x144_crop_center-center_none',1,0,0,'2023-12-04 16:02:16','2023-12-04 16:02:16','2023-12-04 16:02:17','255e2e14-132d-4ca9-aaee-ab933278cb18'),(60,37,'craft\\imagetransforms\\ImageTransformer','sprigcart-preview.png',NULL,'_34x20_crop_center-center_none',1,0,0,'2023-12-04 16:02:19','2023-12-04 16:02:19','2023-12-04 16:02:19','8b80d2f3-b758-4da2-973e-ad5021c01176'),(61,37,'craft\\imagetransforms\\ImageTransformer','sprigcart-preview.png',NULL,'_68x40_crop_center-center_none',1,0,0,'2023-12-04 16:02:19','2023-12-04 16:02:19','2023-12-04 16:02:19','ad870372-a9ec-4623-a3cd-7b071fd0aaa1'),(62,37,'craft\\imagetransforms\\ImageTransformer','sprigcart-preview.png',NULL,'_banner',1,0,0,'2023-12-04 16:05:29','2023-12-04 16:05:29','2023-12-04 16:05:29','c4ca65f6-beb7-4461-b6e6-fefca2e591f4'),(63,34,'craft\\imagetransforms\\ImageTransformer','walkator-klMii3cR9iI-unsplash.jpg',NULL,'_banner',1,0,0,'2023-12-04 16:05:29','2023-12-04 16:05:29','2023-12-04 16:05:29','66576de5-6731-462d-a63a-51f774dc1b7b'),(64,31,'craft\\imagetransforms\\ImageTransformer','ttfb-map-warmed-full.png',NULL,'_banner',1,0,0,'2023-12-04 16:05:29','2023-12-04 16:05:29','2023-12-04 16:05:29','392cb797-c3d2-44da-b160-b55279c49dbe'),(65,16,'craft\\imagetransforms\\ImageTransformer','thumb3_2023-12-04-135245_rxoi.jpg',NULL,'_34x25_crop_center-center_none',1,0,0,'2023-12-08 14:45:17','2023-12-08 14:45:17','2023-12-08 14:45:17','3a130186-0821-44d8-99fb-3a21824c98d7'),(66,16,'craft\\imagetransforms\\ImageTransformer','thumb3_2023-12-04-135245_rxoi.jpg',NULL,'_68x51_crop_center-center_none',1,0,0,'2023-12-08 14:45:17','2023-12-08 14:45:17','2023-12-08 14:45:22','ecf01088-8bf4-437c-a5ba-37bd1fe6f3df'),(67,12,'craft\\imagetransforms\\ImageTransformer','thumb3.jpg',NULL,'_34x25_crop_center-center_none',1,0,0,'2023-12-08 14:45:17','2023-12-08 14:45:17','2023-12-08 14:45:17','f9c5c68c-729d-4f25-97c6-55fceac3affd'),(68,12,'craft\\imagetransforms\\ImageTransformer','thumb3.jpg',NULL,'_68x51_crop_center-center_none',1,0,0,'2023-12-08 14:45:17','2023-12-08 14:45:17','2023-12-08 14:45:22','43da80bb-65ef-48cd-8098-7b314abdf9ba'),(69,8,'craft\\imagetransforms\\ImageTransformer','thumb2.jpg',NULL,'_34x25_crop_center-center_none',1,0,0,'2023-12-08 14:45:17','2023-12-08 14:45:17','2023-12-08 14:45:17','67661507-68e0-45af-8b81-26eb35605f7e'),(70,8,'craft\\imagetransforms\\ImageTransformer','thumb2.jpg',NULL,'_68x51_crop_center-center_none',1,0,0,'2023-12-08 14:45:17','2023-12-08 14:45:17','2023-12-08 14:45:22','98d7399e-6ae4-4147-99f7-98e703c5e34c'),(71,4,'craft\\imagetransforms\\ImageTransformer','thumb1.jpg',NULL,'_34x25_crop_center-center_none',1,0,0,'2023-12-08 14:45:17','2023-12-08 14:45:17','2023-12-08 14:45:18','3d957668-8c46-4e24-a33c-cd85293b8c0f'),(72,4,'craft\\imagetransforms\\ImageTransformer','thumb1.jpg',NULL,'_68x51_crop_center-center_none',1,0,0,'2023-12-08 14:45:17','2023-12-08 14:45:17','2023-12-08 14:45:22','9707e648-595d-4b68-bb61-87cda503772c');
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ngiqurdnployqkgkfzznnskqcintgthapkwt` (`name`),
  KEY `idx_olctvsmjqcqopdnnwflxtlinmvxcbbkdleqv` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
INSERT INTO `imagetransforms` VALUES (1,'banner','banner','crop','center-center',500,200,NULL,NULL,'none',NULL,1,'2023-12-04 14:33:07','2023-12-04 14:33:07','2023-12-04 14:33:07','b302b1e4-a681-487f-9c76-6de79e7ee387'),(2,'thumbnail','thumbnail','crop','center-center',400,300,NULL,NULL,'none',NULL,1,'2023-12-04 14:42:48','2023-12-04 14:33:28','2023-12-04 14:42:48','fb167894-a519-40be-8e01-d55377228e28'),(3,'header','header','crop','center-center',800,320,NULL,NULL,'none',NULL,1,'2023-12-04 14:34:21','2023-12-04 14:34:21','2023-12-04 14:34:21','de1a10d2-7a7a-4daa-af1b-745162e5b7f3');
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'4.5.11.1','4.5.3.0',0,'xkdiexowxlur','3@lakrboociq','2023-12-04 13:07:51','2023-12-04 16:48:35','5d1ea233-30e7-4413-a875-8e0d0ea1dd04');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zsdwdxkqjtpfmjifeehlffcnocucngrodmet` (`primaryOwnerId`),
  KEY `idx_uitqoacvywnmrnjfalnbrnreubuaubgrxazn` (`fieldId`),
  KEY `idx_khvvakeervzuxnagkiqlncaaclvqtpodfxfq` (`typeId`),
  CONSTRAINT `fk_fsurpujoyxiorwqiabafcshdedogokvcrquh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_icgelohrdjmstvnmrsjzhptqvypicgeileos` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nxgdwcgcaezkagdkndaegczbgpapozhwswzo` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pangjjqkkmnnkuwapwcafpmunyncqubpqgom` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_mxndmokomecfhhnzpziewvzqpeayntqkchys` (`ownerId`),
  CONSTRAINT `fk_ecmlfcxokmpqecoumgccpxmwfexuuvfiumkv` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mxndmokomecfhhnzpziewvzqpeayntqkchys` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_swnoyiwhwexvboqqynfrhscaaqsjakesmozc` (`name`,`fieldId`),
  KEY `idx_jiuamvgyrukajuyxlhyjmiknushrwqhcyfxk` (`handle`,`fieldId`),
  KEY `idx_iyheaniphpeatfpibjlyselaxcvdnzcxmbub` (`fieldId`),
  KEY `idx_cehxhzixqrxswckcmukdoxhokaxjuglbenji` (`fieldLayoutId`),
  CONSTRAINT `fk_nhrofgmpqfwgesmrzzcwfuccvszrjrdufxcy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_piheomsbqjffoyvtqzmaypfefjayqbncyrmd` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zelwzdjmouevkdycsuhwqqvtjcinxrmbzgcf` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','56e7f184-feea-475b-bd5c-de0980e2aa4d'),(2,'craft','m210121_145800_asset_indexing_changes','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','4ddb8e57-3701-4fdc-bdca-88ca4c6efa97'),(3,'craft','m210624_222934_drop_deprecated_tables','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','ef0427ac-2565-48a6-afc1-95259547d6fe'),(4,'craft','m210724_180756_rename_source_cols','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','be82eb70-2a8a-4329-a613-43d6b374ff1d'),(5,'craft','m210809_124211_remove_superfluous_uids','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','8e3ed0bf-c7af-47d7-ac90-bace63e88c64'),(6,'craft','m210817_014201_universal_users','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','5c396c6f-a37c-48cb-86cf-7d2078cdeaf3'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','54ad2e3c-c671-4307-bd2d-281c3ee88cf8'),(8,'craft','m211115_135500_image_transformers','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','e60f1245-a5b5-4995-b630-ea78a07f419f'),(9,'craft','m211201_131000_filesystems','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','758c5465-181e-43c8-9772-a63967621fa2'),(10,'craft','m220103_043103_tab_conditions','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','ad39f4a0-e8ae-4e71-a834-c8a13fdcdd96'),(11,'craft','m220104_003433_asset_alt_text','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','ef619c7d-7445-446c-acf8-a1f66a0fd5f1'),(12,'craft','m220123_213619_update_permissions','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','1d802af1-653c-48b6-b390-16282c71e005'),(13,'craft','m220126_003432_addresses','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','cb7f7db3-9e09-4c95-ba90-5713a3bf57bf'),(14,'craft','m220209_095604_add_indexes','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','2ddbe665-43a7-4ed2-9685-9e476a56f030'),(15,'craft','m220213_015220_matrixblocks_owners_table','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','0296c820-1d80-434f-a254-0039de684f9c'),(16,'craft','m220214_000000_truncate_sessions','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','896639c3-f23f-4932-95c5-86b2b66a6797'),(17,'craft','m220222_122159_full_names','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','38395299-8c20-428a-8601-ff45d853582e'),(18,'craft','m220223_180559_nullable_address_owner','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','9d51bbc2-5cc4-487c-97c8-30e338d59cf9'),(19,'craft','m220225_165000_transform_filesystems','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','728c56fd-f8c6-4dec-8a96-aaa3bc018dac'),(20,'craft','m220309_152006_rename_field_layout_elements','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','889530bb-aa30-47d3-ba07-b4400f7380cd'),(21,'craft','m220314_211928_field_layout_element_uids','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','930c406b-bb4e-4d6e-a374-08712aee3443'),(22,'craft','m220316_123800_transform_fs_subpath','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','1396585c-308f-474d-883a-e11f0071903e'),(23,'craft','m220317_174250_release_all_jobs','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','e5641746-07b1-4966-811f-a26a1f1993ff'),(24,'craft','m220330_150000_add_site_gql_schema_components','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','ea38d9c7-2357-4920-b689-2ffc1ddd5eb4'),(25,'craft','m220413_024536_site_enabled_string','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','17630304-24fb-4abd-ba0b-3b65a20279cf'),(26,'craft','m221027_160703_add_image_transform_fill','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','8059a2df-8f7b-482d-907a-1067cd420fd7'),(27,'craft','m221028_130548_add_canonical_id_index','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','39b0464b-4615-46f0-845f-3acc7224e882'),(28,'craft','m221118_003031_drop_element_fks','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','d429acdd-2d4c-406f-9db7-760121e361d5'),(29,'craft','m230131_120713_asset_indexing_session_new_options','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','626ba39a-9087-4adb-bfce-8226b60d84ba'),(30,'craft','m230226_013114_drop_plugin_license_columns','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','0f776e6c-ea2f-43cf-b97f-337af6353b28'),(31,'craft','m230531_123004_add_entry_type_show_status_field','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','20087501-b8f6-4948-889f-14b601fd0a5e'),(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','bdc6d865-fcbb-427a-8fa1-68734531fd97'),(33,'craft','m230710_162700_element_activity','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','8e33c67d-0f12-41a5-bc69-1ef171675279'),(34,'craft','m230820_162023_fix_cache_id_type','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','31b801bf-4eeb-4b43-980a-ba5e80fe4c26'),(35,'craft','m230826_094050_fix_session_id_type','2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-04 13:07:52','f7ceea4b-f40a-49e9-b461-ecdcc0a1d9be'),(36,'plugin:abm-tinymce','Install','2023-12-04 16:21:49','2023-12-04 16:21:49','2023-12-04 16:21:49','57774c87-1a3b-4da4-afaf-c59ccc9caad2');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ihtqvwhkhcmepknlgjujlxdfbxygigvfpexz` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'abm-tinymce','1.0.5','1.0.0','2023-12-04 16:21:49','2023-12-04 16:21:49','2023-12-04 16:21:49','204d6e5a-a7b5-462d-991c-1da74a545d17');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1701708515'),('email.fromEmail','\"stijnvanpeborgh@gmail.com\"'),('email.fromName','\"craft-news-a\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elementCondition','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.autocapitalize','true'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.autocomplete','false'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.autocorrect','true'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.class','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.disabled','false'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.elementCondition','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.id','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.instructions','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.label','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.max','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.min','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.name','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.orientation','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.placeholder','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.readonly','false'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.requirable','false'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.size','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.step','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.tip','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.title','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.uid','\"1eca2057-f493-422e-939b-e4734474092d\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.userCondition','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.warning','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.0.width','100'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.elementCondition','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.fieldUid','\"2365e01a-20c7-42cd-866f-4e4a79bca25d\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.instructions','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.label','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.required','true'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.tip','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.uid','\"ccdaf57b-80fd-472b-9957-ae89c6bb3669\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.userCondition','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.warning','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.elements.1.width','100'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.name','\"Content\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.uid','\"7bcc3910-2c32-4281-8378-0f24376e962f\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.fieldLayouts.0a4c6db9-88e2-40b3-b89c-1b1d66abcea4.tabs.0.userCondition','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.handle','\"aboutUs\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.hasTitleField','false'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.name','\"About Us\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.section','\"41ef28ee-33e4-4efc-812e-0bc56289e5f5\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.showStatusField','true'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.slugTranslationKeyFormat','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.slugTranslationMethod','\"site\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.sortOrder','1'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.titleFormat','\"{section.name|raw}\"'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.titleTranslationKeyFormat','null'),('entryTypes.2a4f59e5-acf8-4fc7-806a-462bb7563eac.titleTranslationMethod','\"site\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elementCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.autocapitalize','true'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.autocomplete','false'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.autocorrect','true'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.class','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.disabled','false'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.elementCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.id','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.instructions','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.label','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.max','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.min','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.name','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.orientation','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.placeholder','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.readonly','false'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.requirable','false'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.size','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.step','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.tip','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.title','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.uid','\"d6cebffa-ced0-4b87-81ee-88b087f5f4cb\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.userCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.warning','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.0.width','100'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.elementCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.fieldUid','\"ce59be17-e13d-420b-99b1-1268579e502d\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.instructions','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.label','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.required','true'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.tip','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.uid','\"ba690d01-c728-4f37-8d40-4577186d471b\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.userCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.warning','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.1.width','100'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.elementCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.fieldUid','\"6a3950ce-58b7-4be3-8c15-42f377f723bf\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.instructions','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.label','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.required','true'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.tip','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.uid','\"bdb89a85-418b-4838-8444-7da85fb84d68\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.userCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.warning','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.2.width','100'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.elementCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.fieldUid','\"714c9b9d-857c-412e-b00e-8d001081adb3\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.instructions','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.label','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.required','true'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.tip','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.uid','\"7ad37b22-adcb-423c-b462-5035bf96d4a3\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.userCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.warning','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.elements.3.width','100'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.name','\"Content\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.uid','\"69f2d38c-bb3b-412a-9b4c-d061be2a23be\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.fieldLayouts.26575e64-8a47-4e27-ae72-46f53880825d.tabs.0.userCondition','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.handle','\"default\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.hasTitleField','true'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.name','\"Default\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.section','\"6a9b7673-68f9-4fb7-b69b-c64cf1831e25\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.showStatusField','true'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.slugTranslationKeyFormat','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.slugTranslationMethod','\"site\"'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.sortOrder','1'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.titleFormat','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.titleTranslationKeyFormat','null'),('entryTypes.3d20e2e1-db9a-4c48-87ea-da43f742096b.titleTranslationMethod','\"site\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elementCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.autocapitalize','true'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.autocomplete','false'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.autocorrect','true'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.class','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.disabled','false'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.elementCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.id','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.instructions','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.label','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.max','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.min','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.name','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.orientation','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.placeholder','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.readonly','false'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.requirable','false'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.size','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.step','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.tip','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.title','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.uid','\"aa602f0a-decd-44b5-aa30-b8a5d92515c2\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.userCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.warning','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.0.width','100'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.elementCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.fieldUid','\"ce59be17-e13d-420b-99b1-1268579e502d\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.instructions','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.label','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.required','true'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.tip','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.uid','\"a63959c4-335a-4d43-9f83-cca5ecc10290\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.userCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.warning','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.1.width','100'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.elementCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.fieldUid','\"6a3950ce-58b7-4be3-8c15-42f377f723bf\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.instructions','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.label','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.required','true'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.tip','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.uid','\"4297dec0-01b2-4eca-8bf6-ca50b23d6cce\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.userCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.warning','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.2.width','100'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.elementCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.fieldUid','\"a88d603b-3570-44bf-b52a-1eda34742597\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.instructions','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.label','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.required','true'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.tip','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.uid','\"a54e9e80-7ccf-4eab-a61c-7af4f477f12e\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.userCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.warning','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.3.width','100'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.elementCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.fieldUid','\"82e46b3b-d595-48b8-8cb7-e5155bd16e7b\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.instructions','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.label','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.required','true'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.tip','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.uid','\"1592f9e2-3d23-448f-83ff-066029bc863f\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.userCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.warning','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.elements.4.width','100'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.name','\"Content\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.uid','\"fa7f4462-90e1-4803-970a-585eb3fa12df\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.fieldLayouts.0d8d105f-94a5-4489-9ad8-93de281b8a28.tabs.0.userCondition','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.handle','\"default\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.hasTitleField','true'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.name','\"Default\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.section','\"2b10cb7c-e848-483c-ae2d-fd185096e8df\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.showStatusField','true'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.slugTranslationKeyFormat','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.slugTranslationMethod','\"site\"'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.sortOrder','1'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.titleFormat','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.titleTranslationKeyFormat','null'),('entryTypes.c7901917-c90e-418e-83ff-0cfbab9fdac0.titleTranslationMethod','\"site\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elementCondition','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.autocapitalize','true'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.autocomplete','false'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.autocorrect','true'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.class','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.disabled','false'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.elementCondition','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.id','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.instructions','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.label','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.max','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.min','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.name','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.orientation','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.placeholder','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.readonly','false'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.requirable','false'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.size','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.step','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.tip','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.title','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.uid','\"c43c1445-f464-4030-b940-3860611762e8\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.userCondition','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.warning','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.0.width','100'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.elementCondition','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.fieldUid','\"2365e01a-20c7-42cd-866f-4e4a79bca25d\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.instructions','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.label','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.required','false'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.tip','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.uid','\"40b20664-95d3-45c6-9096-652f0d154fcc\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.userCondition','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.warning','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.elements.1.width','100'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.name','\"Content\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.uid','\"4fd009a8-92e4-4754-a3f0-0b9446e703d4\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.fieldLayouts.f919f605-9920-4bc0-a87c-4523cb2566b0.tabs.0.userCondition','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.handle','\"headerTitle\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.hasTitleField','false'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.name','\"header title\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.section','\"12332128-52a9-4990-b53f-ad5bdd81cd4c\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.showStatusField','true'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.slugTranslationKeyFormat','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.slugTranslationMethod','\"site\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.sortOrder','1'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.titleFormat','\"{section.name|raw}\"'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.titleTranslationKeyFormat','null'),('entryTypes.cbf49ce7-fba8-499b-a0fc-6e39468730c6.titleTranslationMethod','\"site\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elementCondition','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.autocapitalize','true'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.autocomplete','false'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.autocorrect','true'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.class','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.disabled','false'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.elementCondition','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.id','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.instructions','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.label','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.max','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.min','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.name','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.orientation','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.placeholder','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.readonly','false'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.requirable','false'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.size','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.step','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.tip','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.title','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.uid','\"ddcaea1d-de36-4568-94ae-d31e44ece84f\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.userCondition','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.warning','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.0.width','100'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.elementCondition','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.fieldUid','\"2365e01a-20c7-42cd-866f-4e4a79bca25d\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.instructions','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.label','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.required','true'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.tip','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.uid','\"2a46cd48-5c84-4785-9610-720f11ce03b4\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.userCondition','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.warning','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.elements.1.width','100'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.name','\"Content\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.uid','\"20765f3e-54b4-4f12-bfd3-98fef53708da\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.fieldLayouts.e8bf7b77-9a15-4ab9-8580-fe9942fd9ff4.tabs.0.userCondition','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.handle','\"footer\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.hasTitleField','false'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.name','\"footer\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.section','\"5261768b-6f80-4a42-b41c-da70d1de28d6\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.showStatusField','true'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.slugTranslationKeyFormat','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.slugTranslationMethod','\"site\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.sortOrder','1'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.titleFormat','\"{section.name|raw}\"'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.titleTranslationKeyFormat','null'),('entryTypes.e4b12178-c53b-4272-ac65-501a0d084bcd.titleTranslationMethod','\"site\"'),('fieldGroups.784b6530-b0a2-46f1-a5cc-008816f6ad32.name','\"Common\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.columnSuffix','\"xnzochyb\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.contentColumnType','\"text\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.fieldGroup','\"784b6530-b0a2-46f1-a5cc-008816f6ad32\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.handle','\"richText\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.instructions','null'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.name','\"rich text\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.searchable','false'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.availableTransforms','\"*\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.availableVolumes','\"*\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.columnType','\"text\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.purifierConfig','\"Default.json\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.purifyHtml','true'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.removeEmptyTags','false'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.removeInlineStyles','false'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.removeNbsp','false'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.showHtmlButtonForNonAdmins','true'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.showUnpermittedFiles','false'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.showUnpermittedVolumes','false'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.settings.tinymceConfig','\"Default.json\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.translationKeyFormat','null'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.translationMethod','\"none\"'),('fields.2365e01a-20c7-42cd-866f-4e4a79bca25d.type','\"abmat\\\\tinymce\\\\Field\"'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.columnSuffix','\"yprwwwti\"'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.contentColumnType','\"text\"'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.fieldGroup','\"784b6530-b0a2-46f1-a5cc-008816f6ad32\"'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.handle','\"introText\"'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.instructions','null'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.name','\"intro text\"'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.searchable','false'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.settings.byteLimit','null'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.settings.charLimit','400'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.settings.code','false'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.settings.columnType','null'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.settings.initialRows','4'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.settings.multiline','false'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.settings.placeholder','null'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.settings.uiMode','\"normal\"'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.translationKeyFormat','null'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.translationMethod','\"none\"'),('fields.6a3950ce-58b7-4be3-8c15-42f377f723bf.type','\"craft\\\\fields\\\\PlainText\"'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.columnSuffix','\"gninfktw\"'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.contentColumnType','\"text\"'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.fieldGroup','\"784b6530-b0a2-46f1-a5cc-008816f6ad32\"'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.handle','\"fullText\"'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.instructions','null'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.name','\"full text\"'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.searchable','false'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.settings.byteLimit','null'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.settings.charLimit','null'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.settings.code','false'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.settings.columnType','null'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.settings.initialRows','4'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.settings.multiline','false'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.settings.placeholder','null'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.settings.uiMode','\"normal\"'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.translationKeyFormat','null'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.translationMethod','\"none\"'),('fields.714c9b9d-857c-412e-b00e-8d001081adb3.type','\"craft\\\\fields\\\\PlainText\"'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.columnSuffix','\"kztiozrj\"'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.contentColumnType','\"string(255)\"'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.fieldGroup','\"784b6530-b0a2-46f1-a5cc-008816f6ad32\"'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.handle','\"storeUrl\"'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.instructions','null'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.name','\"store url\"'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.searchable','false'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.settings.maxLength','255'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.settings.types.0','\"url\"'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.translationKeyFormat','null'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.translationMethod','\"none\"'),('fields.82e46b3b-d595-48b8-8cb7-e5155bd16e7b.type','\"craft\\\\fields\\\\Url\"'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.columnSuffix','\"strxivmx\"'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.contentColumnType','\"smallint(1)\"'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.fieldGroup','\"784b6530-b0a2-46f1-a5cc-008816f6ad32\"'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.handle','\"rating\"'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.instructions','null'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.name','\"Rating\"'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.searchable','false'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.settings.decimals','0'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.settings.defaultValue','null'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.settings.max','5'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.settings.min','0'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.settings.prefix','null'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.settings.previewCurrency','null'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.settings.previewFormat','\"decimal\"'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.settings.size','null'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.settings.suffix','null'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.translationKeyFormat','null'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.translationMethod','\"none\"'),('fields.a88d603b-3570-44bf-b52a-1eda34742597.type','\"craft\\\\fields\\\\Number\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.columnSuffix','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.contentColumnType','\"string\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.fieldGroup','\"784b6530-b0a2-46f1-a5cc-008816f6ad32\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.handle','\"bannerImage\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.instructions','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.name','\"banner image\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.searchable','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.allowedKinds','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.allowSelfRelations','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.allowSubfolders','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.allowUploads','true'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.branchLimit','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.defaultUploadLocationSource','\"volume:027709b3-b422-4204-9597-c132f25a8567\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.defaultUploadLocationSubpath','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.localizeRelations','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.maintainHierarchy','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.maxRelations','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.minRelations','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.previewMode','\"thumbs\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.restrictedDefaultUploadSubpath','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.restrictedLocationSource','\"volume:027709b3-b422-4204-9597-c132f25a8567\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.restrictedLocationSubpath','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.restrictFiles','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.restrictLocation','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.0','\"conditionRules\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.0.0','\"class\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.0.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\FileSizeConditionRule\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.1.0','\"uid\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.1.1','\"f1b32762-b378-467f-b542-f6bf9fffc145\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.2.0','\"operator\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.2.1','\"<\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.3.0','\"value\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.3.1','\"100\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.4.0','\"maxValue\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.4.1','\"\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.5.0','\"unit\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionCondition.__assoc__.3.1.0.__assoc__.5.1','\"MB\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.selectionLabel','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.showSiteMenu','true'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.showUnpermittedFiles','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.showUnpermittedVolumes','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.sources','\"*\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.targetSiteId','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.validateRelatedElements','false'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.settings.viewMode','\"large\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.translationKeyFormat','null'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.translationMethod','\"site\"'),('fields.ce59be17-e13d-420b-99b1-1268579e502d.type','\"craft\\\\fields\\\\Assets\"'),('fs.assets.hasUrls','true'),('fs.assets.name','\"assets\"'),('fs.assets.settings.path','\"@webroot/assets\"'),('fs.assets.type','\"craft\\\\fs\\\\Local\"'),('fs.assets.url','\"@web/assets\"'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.fill','null'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.format','null'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.handle','\"banner\"'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.height','200'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.interlace','\"none\"'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.mode','\"crop\"'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.name','\"banner\"'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.position','\"center-center\"'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.quality','null'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.upscale','true'),('imageTransforms.b302b1e4-a681-487f-9c76-6de79e7ee387.width','500'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.fill','null'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.format','null'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.handle','\"header\"'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.height','320'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.interlace','\"none\"'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.mode','\"crop\"'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.name','\"header\"'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.position','\"center-center\"'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.quality','null'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.upscale','true'),('imageTransforms.de1a10d2-7a7a-4daa-af1b-745162e5b7f3.width','800'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.fill','null'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.format','null'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.handle','\"thumbnail\"'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.height','300'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.interlace','\"none\"'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.mode','\"crop\"'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.name','\"thumbnail\"'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.position','\"center-center\"'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.quality','null'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.upscale','true'),('imageTransforms.fb167894-a519-40be-8e01-d55377228e28.width','400'),('meta.__names__.027709b3-b422-4204-9597-c132f25a8567','\"news-assets\"'),('meta.__names__.12332128-52a9-4990-b53f-ad5bdd81cd4c','\"header title\"'),('meta.__names__.20ed0978-d429-469b-8568-7ea52c32c967','\"craft-news-a\"'),('meta.__names__.22157584-fdf0-40c9-817d-207e92689d61','\"craft-news-a\"'),('meta.__names__.2365e01a-20c7-42cd-866f-4e4a79bca25d','\"rich text\"'),('meta.__names__.2a4f59e5-acf8-4fc7-806a-462bb7563eac','\"About Us\"'),('meta.__names__.2b10cb7c-e848-483c-ae2d-fd185096e8df','\"plugin reviews\"'),('meta.__names__.3d20e2e1-db9a-4c48-87ea-da43f742096b','\"Default\"'),('meta.__names__.41ef28ee-33e4-4efc-812e-0bc56289e5f5','\"About Us\"'),('meta.__names__.5261768b-6f80-4a42-b41c-da70d1de28d6','\"footer\"'),('meta.__names__.6a3950ce-58b7-4be3-8c15-42f377f723bf','\"intro text\"'),('meta.__names__.6a9b7673-68f9-4fb7-b69b-c64cf1831e25','\"news\"'),('meta.__names__.714c9b9d-857c-412e-b00e-8d001081adb3','\"full text\"'),('meta.__names__.784b6530-b0a2-46f1-a5cc-008816f6ad32','\"Common\"'),('meta.__names__.82e46b3b-d595-48b8-8cb7-e5155bd16e7b','\"store url\"'),('meta.__names__.a88d603b-3570-44bf-b52a-1eda34742597','\"Rating\"'),('meta.__names__.b302b1e4-a681-487f-9c76-6de79e7ee387','\"banner\"'),('meta.__names__.c7901917-c90e-418e-83ff-0cfbab9fdac0','\"Default\"'),('meta.__names__.cbf49ce7-fba8-499b-a0fc-6e39468730c6','\"header title\"'),('meta.__names__.ce59be17-e13d-420b-99b1-1268579e502d','\"banner image\"'),('meta.__names__.de1a10d2-7a7a-4daa-af1b-745162e5b7f3','\"header\"'),('meta.__names__.e4b12178-c53b-4272-ac65-501a0d084bcd','\"footer\"'),('meta.__names__.fb167894-a519-40be-8e01-d55377228e28','\"thumbnail\"'),('plugins.abm-tinymce.edition','\"standard\"'),('plugins.abm-tinymce.enabled','true'),('plugins.abm-tinymce.schemaVersion','\"1.0.0\"'),('routes.2339605e-83c4-4531-9de6-9faaa784e067.siteUid','null'),('routes.2339605e-83c4-4531-9de6-9faaa784e067.sortOrder','1'),('routes.2339605e-83c4-4531-9de6-9faaa784e067.template','\"news/_allnews\"'),('routes.2339605e-83c4-4531-9de6-9faaa784e067.uriParts.0','\"news\"'),('routes.2339605e-83c4-4531-9de6-9faaa784e067.uriPattern','\"news\"'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.defaultPlacement','\"end\"'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.enableVersioning','true'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.handle','\"headerTitle\"'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.name','\"header title\"'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.propagationMethod','\"all\"'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.enabledByDefault','true'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.hasUrls','true'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.template','\"header-title/_entry\"'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.uriFormat','\"header-title\"'),('sections.12332128-52a9-4990-b53f-ad5bdd81cd4c.type','\"single\"'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.defaultPlacement','\"end\"'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.enableVersioning','true'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.handle','\"pluginReviews\"'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.name','\"plugin reviews\"'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.propagationMethod','\"all\"'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.enabledByDefault','true'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.hasUrls','true'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.template','\"plugin-reviews/_entry\"'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.uriFormat','\"plugin-reviews/{slug}\"'),('sections.2b10cb7c-e848-483c-ae2d-fd185096e8df.type','\"channel\"'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.defaultPlacement','\"end\"'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.enableVersioning','true'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.handle','\"aboutUs\"'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.name','\"About Us\"'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.propagationMethod','\"all\"'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.enabledByDefault','true'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.hasUrls','true'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.template','\"_about.twig\"'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.uriFormat','\"about-us\"'),('sections.41ef28ee-33e4-4efc-812e-0bc56289e5f5.type','\"single\"'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.defaultPlacement','\"end\"'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.enableVersioning','true'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.handle','\"footer\"'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.name','\"footer\"'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.propagationMethod','\"all\"'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.enabledByDefault','true'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.hasUrls','true'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.template','\"footer/_entry\"'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.uriFormat','\"footer\"'),('sections.5261768b-6f80-4a42-b41c-da70d1de28d6.type','\"single\"'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.defaultPlacement','\"end\"'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.enableVersioning','true'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.handle','\"news\"'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.name','\"news\"'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.propagationMethod','\"all\"'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.enabledByDefault','true'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.hasUrls','true'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.template','\"news/_entry\"'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.siteSettings.22157584-fdf0-40c9-817d-207e92689d61.uriFormat','\"news/{slug}\"'),('sections.6a9b7673-68f9-4fb7-b69b-c64cf1831e25.type','\"channel\"'),('siteGroups.20ed0978-d429-469b-8568-7ea52c32c967.name','\"craft-news-a\"'),('sites.22157584-fdf0-40c9-817d-207e92689d61.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.22157584-fdf0-40c9-817d-207e92689d61.handle','\"default\"'),('sites.22157584-fdf0-40c9-817d-207e92689d61.hasUrls','true'),('sites.22157584-fdf0-40c9-817d-207e92689d61.language','\"en-US\"'),('sites.22157584-fdf0-40c9-817d-207e92689d61.name','\"craft-news-a\"'),('sites.22157584-fdf0-40c9-817d-207e92689d61.primary','true'),('sites.22157584-fdf0-40c9-817d-207e92689d61.siteGroup','\"20ed0978-d429-469b-8568-7ea52c32c967\"'),('sites.22157584-fdf0-40c9-817d-207e92689d61.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"craft-news-a\"'),('system.schemaVersion','\"4.5.3.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elementCondition','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.autocapitalize','true'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.autocomplete','false'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.autocorrect','true'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.class','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.disabled','false'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.elementCondition','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.id','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.instructions','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.label','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.max','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.min','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.name','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.orientation','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.placeholder','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.readonly','false'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.requirable','false'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.size','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.step','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.tip','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.title','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.uid','\"3cbed65d-e6b8-42af-8582-a5df10f8c3a6\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.userCondition','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.warning','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.0.width','100'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.attribute','\"alt\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.class','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.cols','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.disabled','false'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.elementCondition','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.id','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.instructions','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.label','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.name','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.orientation','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.placeholder','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.readonly','false'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.requirable','true'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.required','false'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.rows','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.tip','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.title','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.uid','\"3b73a910-52d9-4ab5-a254-4e3e852720d4\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.userCondition','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.warning','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.elements.1.width','100'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.name','\"Content\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.uid','\"322464b6-0fee-4876-9731-59d98b6c6334\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fieldLayouts.804c1a05-0ef6-4213-bfb2-869337758a87.tabs.0.userCondition','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.fs','\"assets\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.handle','\"newsAssets\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.name','\"news-assets\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.sortOrder','1'),('volumes.027709b3-b422-4204-9597-c132f25a8567.titleTranslationKeyFormat','null'),('volumes.027709b3-b422-4204-9597-c132f25a8567.titleTranslationMethod','\"site\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.transformFs','\"assets\"'),('volumes.027709b3-b422-4204-9597-c132f25a8567.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_simbpbnrjcwztdkiymppzdtackouxybtgpcd` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_llrmmepqeudnqwqcgmjjolagirmutbreponq` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=287 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_taojcmgkyzgqtqcggkxomysjuectyxafctgn` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_mlondzacrbddsgurwldenmcbtfhhgerwbali` (`sourceId`),
  KEY `idx_zzqkhjdhlqoqzohfpenwzjwoksbbwsjqiaoa` (`targetId`),
  KEY `idx_cemegqqvtmonxpmyyorjrwuivbrykeqicuvb` (`sourceSiteId`),
  CONSTRAINT `fk_dydegnqdcjrjmiaozgufzyjcnokgwgylqcci` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kxcotaimqvpbpqsnmqalrmjegkrmszsxgxoh` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_paqsgdlcdtoajpvnlhkcydhwrevlvxkhhfcz` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (3,3,5,NULL,3,1,'2023-12-04 13:49:55','2023-12-04 13:49:55','96b7855a-a7a9-425a-be95-b10cde5671ee'),(7,3,9,NULL,7,1,'2023-12-04 13:51:12','2023-12-04 13:51:12','38a9bbf9-7eb9-438b-8654-823c853d160b'),(11,3,13,NULL,11,1,'2023-12-04 13:51:48','2023-12-04 13:51:48','49024064-5cff-47d9-babf-e29d4fdda7fc'),(15,3,17,NULL,15,1,'2023-12-04 13:53:30','2023-12-04 13:53:30','e4a22196-87df-42a9-a696-585ac7a10f5e'),(19,3,14,NULL,19,1,'2023-12-04 14:38:51','2023-12-04 14:38:51','2a04e42d-f08d-4504-abd3-2001caf4ae55'),(20,3,20,NULL,19,1,'2023-12-04 14:38:51','2023-12-04 14:38:51','ceedf47c-bccb-47bb-acfe-84a5dd4516bc'),(23,3,6,NULL,22,1,'2023-12-04 14:39:00','2023-12-04 14:39:00','7ae72f0a-c9ad-43e8-a228-d5428303513b'),(24,3,23,NULL,22,1,'2023-12-04 14:39:00','2023-12-04 14:39:00','184c2857-f2e3-4a45-9b1d-f1bf4caaf308'),(27,3,10,NULL,24,1,'2023-12-04 14:39:15','2023-12-04 14:39:15','5cd7581c-687e-4cea-b172-565a7b03ac26'),(28,3,26,NULL,24,1,'2023-12-04 14:39:15','2023-12-04 14:39:15','94ef3d35-6096-45cd-ac01-3309c3dea8da'),(31,3,2,NULL,28,1,'2023-12-04 14:39:38','2023-12-04 14:39:38','8acc1f65-d109-45a6-931d-ac46b3671ae3'),(32,3,29,NULL,28,1,'2023-12-04 14:39:39','2023-12-04 14:39:39','35fe9a19-d4f6-464c-b8f7-010f7162b2c2'),(33,3,30,NULL,31,1,'2023-12-04 15:57:31','2023-12-04 15:57:31','57009e80-63d5-4ebb-a5fd-c5c1719f1df8'),(34,3,32,NULL,31,1,'2023-12-04 15:57:34','2023-12-04 15:57:34','6b8eaad8-bd95-4910-9237-c1d54d1dd26e'),(35,3,33,NULL,34,1,'2023-12-04 16:00:17','2023-12-04 16:00:17','69bbb488-1a33-4469-9f03-e099752ae26c'),(36,3,35,NULL,34,1,'2023-12-04 16:00:19','2023-12-04 16:00:19','9a229064-d0cd-41bc-9aa5-77fefa7f2cc8'),(37,3,36,NULL,37,1,'2023-12-04 16:02:17','2023-12-04 16:02:17','20b59a0a-d274-4691-808a-7fc4939c1dc6'),(38,3,38,NULL,37,1,'2023-12-04 16:02:18','2023-12-04 16:02:18','e2c36474-2052-4464-acb0-eaff33bc61b1');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('10f2ea5f','@bower/jquery/dist'),('1512f5b7','@craft/web/assets/elementresizedetector/dist'),('1a157a49','@craft/web/assets/jqueryui/dist'),('215b688d','@craft/web/assets/htmx/dist'),('26076ea0','@craft/web/assets/routes/dist'),('2e8ae971','@craft/web/assets/edituser/dist'),('358dea02','@craft/web/assets/dashboard/dist'),('425cac9c','@config/tinymce/resources'),('43cb4320','@craft/web/assets/velocity/dist'),('460f9ef5','@craft/web/assets/jquerytouchevents/dist'),('465c4197','@craft/web/assets/jquerypayment/dist'),('46eace2','@craft/web/assets/fileupload/dist'),('4cc12f72','@craft/web/assets/edittransform/dist'),('4cceccc9','@craft/web/assets/feed/dist'),('516a3736','@craft/web/assets/plugins/dist'),('57b36b24','@craft/web/assets/editsection/dist'),('57eb9b7b','@craft/web/assets/vue/dist'),('71bf2649','@craft/web/assets/xregexp/dist'),('73dbf18d','@craft/web/assets/craftsupport/dist'),('75756bf5','@craft/web/assets/timepicker/dist'),('794cd681','@craft/web/assets/dbbackup/dist'),('7a079b49','@craft/web/assets/picturefill/dist'),('7bdd4640','@craft/web/assets/login/dist'),('84d170e1','@craft/web/assets/fabric/dist'),('93235d13','@abmat/tinymce/assets/field/dist'),('94cc5de2','@vendor/tinymce/tinymce'),('94fbe6df','@craft/web/assets/utilities/dist'),('ac6347f6','@craft/web/assets/garnish/dist'),('b4c3fcdc','@craft/web/assets/fields/dist'),('bded0409','@craft/web/assets/admintable/dist'),('c2417c5d','@craft/web/assets/selectize/dist'),('c37585c3','@craft/web/assets/installer/dist'),('c554c67f','@craft/web/assets/tailwindreset/dist'),('c772ee68','@craft/web/assets/pluginstore/dist'),('ce09de15','@craft/web/assets/cp/dist'),('d43cf85c','@craft/web/assets/d3/dist'),('d4770784','@craft/web/assets/updateswidget/dist'),('d93424dd','@craft/web/assets/fieldsettings/dist'),('dd5853df','@craft/web/assets/generalsettings/dist'),('df5df1eb','@craft/web/assets/iframeresizer/dist'),('e30e03b5','@craft/web/assets/updater/dist'),('e78fbac2','@craft/web/assets/findreplace/dist'),('e94a2dbe','@craft/web/assets/conditionbuilder/dist'),('eacd45ea','@craft/web/assets/recententries/dist'),('f238d0b3','@craft/web/assets/axios/dist'),('fe68f8b','@craft/web/assets/prismjs/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vjohcxanwkkwglxvmgmjkdmnoyostohxeqkx` (`canonicalId`,`num`),
  KEY `fk_usikgysemworfwmzsvfrbtmeshpjlaixfvpw` (`creatorId`),
  CONSTRAINT `fk_bkhsgyvneefqvszlafgsjihahbsixxrdppqi` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_usikgysemworfwmzsvfrbtmeshpjlaixfvpw` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,''),(2,6,1,1,''),(3,10,1,1,''),(4,14,1,1,''),(5,14,1,2,'Applied “Draft 1”'),(6,6,1,2,'Applied “Draft 1”'),(7,10,1,2,'Applied “Draft 1”'),(8,2,1,2,'Applied “Draft 1”'),(9,30,1,1,''),(10,33,1,1,''),(11,36,1,1,''),(12,39,1,1,NULL),(13,39,1,2,NULL),(14,39,1,3,NULL),(15,39,1,4,'Applied “Draft 1”'),(16,39,1,5,''),(17,39,1,6,''),(18,39,1,7,'Applied “Draft 1”'),(19,39,1,8,'Applied “Draft 1”'),(20,53,1,1,NULL),(21,53,1,2,NULL),(22,53,1,3,NULL),(23,53,1,4,'Applied “Draft 1”'),(24,53,1,5,''),(25,61,1,1,NULL),(26,61,1,2,NULL),(27,61,1,3,NULL),(28,61,1,4,NULL),(29,61,1,5,NULL),(30,61,1,6,''),(31,61,1,7,'');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_fadzskyyvxchyzwbjcvwgrhzxjjxpfkltzfz` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' admin test be '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' flashy article about craft cms '),(2,'title',0,1,' flashy article about craft cms '),(3,'alt',0,1,''),(3,'extension',0,1,' jpg '),(3,'filename',0,1,' banner1 jpg '),(3,'kind',0,1,' image '),(3,'slug',0,1,''),(3,'title',0,1,' banner1 '),(4,'alt',0,1,''),(4,'extension',0,1,' jpg '),(4,'filename',0,1,' thumb1 jpg '),(4,'kind',0,1,' image '),(4,'slug',0,1,''),(4,'title',0,1,' thumb1 '),(6,'slug',0,1,' everything you need to know about craftcms '),(6,'title',0,1,' everything you need to know about craftcms '),(7,'alt',0,1,''),(7,'extension',0,1,' jpg '),(7,'filename',0,1,' banner2 jpg '),(7,'kind',0,1,' image '),(7,'slug',0,1,''),(7,'title',0,1,' banner2 '),(8,'alt',0,1,''),(8,'extension',0,1,' jpg '),(8,'filename',0,1,' thumb2 jpg '),(8,'kind',0,1,' image '),(8,'slug',0,1,''),(8,'title',0,1,' thumb2 '),(10,'slug',0,1,' craft cms vs drupal vs wordpress '),(10,'title',0,1,' craft cms vs drupal vs wordpress '),(11,'alt',0,1,''),(11,'extension',0,1,' jpg '),(11,'filename',0,1,' banner3 jpg '),(11,'kind',0,1,' image '),(11,'slug',0,1,''),(11,'title',0,1,' banner3 '),(12,'alt',0,1,''),(12,'extension',0,1,' jpg '),(12,'filename',0,1,' thumb3 jpg '),(12,'kind',0,1,' image '),(12,'slug',0,1,''),(12,'title',0,1,' thumb3 '),(14,'slug',0,1,' how to improve craft cms performance '),(14,'title',0,1,' how to improve craft cms performance '),(15,'alt',0,1,''),(15,'extension',0,1,' jpg '),(15,'filename',0,1,' banner2 2023 12 04 135241 jnph jpg '),(15,'kind',0,1,' image '),(15,'slug',0,1,''),(15,'title',0,1,' banner2 '),(16,'alt',0,1,''),(16,'extension',0,1,' jpg '),(16,'filename',0,1,' thumb3 2023 12 04 135245 rxoi jpg '),(16,'kind',0,1,' image '),(16,'slug',0,1,''),(16,'title',0,1,' thumb3 '),(19,'alt',0,1,''),(19,'extension',0,1,' jpg '),(19,'filename',0,1,' luke chesser jkutrj4vk00 unsplash jpg '),(19,'kind',0,1,' image '),(19,'slug',0,1,''),(19,'title',0,1,' luke chesser jku tr j4v k00 unsplash '),(22,'alt',0,1,''),(22,'extension',0,1,' jpg '),(22,'filename',0,1,' luca bravo 9l 326fiszk unsplash 2 jpg '),(22,'kind',0,1,' image '),(22,'slug',0,1,''),(22,'title',0,1,' luca bravo 9l 326 fi szk unsplash 2 '),(24,'alt',0,1,''),(24,'extension',0,1,' jpg '),(24,'filename',0,1,' souvik banerjee wprnem 6dg unsplash jpg '),(24,'kind',0,1,' image '),(24,'slug',0,1,''),(24,'title',0,1,' souvik banerjee w pr nem 6dg unsplash '),(28,'alt',0,1,''),(28,'extension',0,1,' jpg '),(28,'filename',0,1,' ilya pavlov oqtafyt5ktw unsplash jpg '),(28,'kind',0,1,' image '),(28,'slug',0,1,''),(28,'title',0,1,' ilya pavlov oqtaf yt5k tw unsplash '),(30,'slug',0,1,' cache igniter fire up your sites performance '),(30,'title',0,1,' cache igniter fire up your sites performance '),(31,'alt',0,1,''),(31,'extension',0,1,' png '),(31,'filename',0,1,' ttfb map warmed full png '),(31,'kind',0,1,' image '),(31,'slug',0,1,''),(31,'title',0,1,' ttfb map warmed full '),(33,'slug',0,1,' minify your html css and js '),(33,'title',0,1,' minify your html css and js '),(34,'alt',0,1,''),(34,'extension',0,1,' jpg '),(34,'filename',0,1,' walkator klmii3cr9ii unsplash jpg '),(34,'kind',0,1,' image '),(34,'slug',0,1,''),(34,'title',0,1,' walkator kl mii3c r9i i unsplash '),(36,'slug',0,1,' sprig reactive components for twig '),(36,'title',0,1,' sprig reactive components for twig '),(37,'alt',0,1,''),(37,'extension',0,1,' png '),(37,'filename',0,1,' sprigcart preview png '),(37,'kind',0,1,' image '),(37,'slug',0,1,''),(37,'title',0,1,' sprigcart preview '),(39,'slug',0,1,' footer '),(39,'title',0,1,' footer '),(53,'slug',0,1,' header title '),(53,'title',0,1,' header title '),(61,'slug',0,1,' about us '),(61,'title',0,1,' about us ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pagyctukysampjflipjipiptqjwlnbifntnq` (`handle`),
  KEY `idx_kahbzbalylkcamekfdhviqkfjnjumihutvbd` (`name`),
  KEY `idx_cgharhruxknjmsvxpumteiwxjvlejukawqqj` (`structureId`),
  KEY `idx_dlxndkrpammcxdfxyumkhvlvcbgjracevcro` (`dateDeleted`),
  CONSTRAINT `fk_jmlyxtffchrgacvtpsabwblgmdhjbttgivha` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'news','news','channel',1,'all','end',NULL,'2023-12-04 13:25:37','2023-12-04 13:25:37',NULL,'6a9b7673-68f9-4fb7-b69b-c64cf1831e25'),(2,NULL,'plugin reviews','pluginReviews','channel',1,'all','end',NULL,'2023-12-04 15:50:19','2023-12-04 15:50:19',NULL,'2b10cb7c-e848-483c-ae2d-fd185096e8df'),(3,NULL,'footer','footer','single',1,'all','end',NULL,'2023-12-04 16:20:03','2023-12-04 16:20:03',NULL,'5261768b-6f80-4a42-b41c-da70d1de28d6'),(4,NULL,'header title','headerTitle','single',1,'all','end',NULL,'2023-12-04 16:38:20','2023-12-04 16:38:20',NULL,'12332128-52a9-4990-b53f-ad5bdd81cd4c'),(5,NULL,'About Us','aboutUs','single',1,'all','end',NULL,'2023-12-04 16:45:25','2023-12-04 16:45:25',NULL,'41ef28ee-33e4-4efc-812e-0bc56289e5f5');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mabmbxmyacjnnicijjkrefvafjezyunxazpi` (`sectionId`,`siteId`),
  KEY `idx_yedvskqrirthjlejcknhalrjduejlrxofefy` (`siteId`),
  CONSTRAINT `fk_pmcthwfzubjtvcsmzbhpacsbjwzhkfosureg` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_szcdolivwvkvtlkvffzllxzinzysyxpwuvql` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'news/{slug}','news/_entry',1,'2023-12-04 13:25:37','2023-12-04 13:25:37','8ae1308c-8291-4bd6-8598-ac051f3965c3'),(2,2,1,1,'plugin-reviews/{slug}','plugin-reviews/_entry',1,'2023-12-04 15:50:19','2023-12-04 15:50:19','77e60ff2-7b76-46d0-a777-a65e2785d08a'),(3,3,1,1,'footer','footer/_entry',1,'2023-12-04 16:20:03','2023-12-04 16:20:03','284215d0-0848-4475-a123-fc717a6a1a78'),(4,4,1,1,'header-title','header-title/_entry',1,'2023-12-04 16:38:20','2023-12-04 16:38:20','ad35085e-27ae-4c3a-964b-45ff1afb6706'),(5,5,1,1,'about-us','_about.twig',1,'2023-12-04 16:45:25','2023-12-04 16:48:35','6400f559-4e5a-48ef-be70-4607e8320415');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_earybfoarrribpwosladfdflemzexaenhokc` (`uid`),
  KEY `idx_cwcygvcestpussucglwyxgxakibyfhmfnwgf` (`token`),
  KEY `idx_vfqbxvkzweoxtomgfzlkyphvnsnbbhvlrths` (`dateUpdated`),
  KEY `idx_uskhqogxrgtjgrjebmrwpsungkrwmbtkhvtl` (`userId`),
  CONSTRAINT `fk_hxamueblxoendmsztggtpkuhzrzxbhzrhbmd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'wlRv3GM2zO_lkuj0heI8DzY3Pw4Zv7IfBnkhoMOm7PY5l1_jP6est-TvimOMGeOVzcmjygTfYYx7PwSL0xhhtlWdyVhLo0Q59p1C','2023-12-04 13:22:19','2023-12-04 16:56:14','2eab0937-8356-497f-a0a7-11c8b749dde9'),(2,1,'KDmqgMwL72cNjedstcPDWdPrncbuFq8VCrEEWePCwGsfqeDw-S41uw5GRrLbDCyhhQiixaUPFW075qSnqM9KklpE7rF-01SIYtTH','2023-12-08 14:45:12','2023-12-08 14:48:44','72e388db-a565-458d-b242-f9181804ff76');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qaxudxikmqjzizzfphctiolnopvnvbmrbgoe` (`userId`,`message`),
  CONSTRAINT `fk_nbdwqrpbpzpqmmummxowgtgvjpfoshecuxdy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hyqyhsgllspneuvskiarlxgnlogwbktfwuuc` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'craft-news-a','2023-12-04 13:07:51','2023-12-04 13:07:51',NULL,'20ed0978-d429-469b-8568-7ea52c32c967');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zljzfowhwvdkqhjxdhxzkmcurxvadgzzxawj` (`dateDeleted`),
  KEY `idx_ezfpdzjchnggepiuidgyfjojbhszzmxtubmd` (`handle`),
  KEY `idx_tdxwcqaffzshxzgoofzjhlyshryovqnybpcc` (`sortOrder`),
  KEY `fk_bpoleaalnenkjbvbsazosjstgszygloynomx` (`groupId`),
  CONSTRAINT `fk_bpoleaalnenkjbvbsazosjstgszygloynomx` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','craft-news-a','default','en-US',1,'$PRIMARY_SITE_URL',1,'2023-12-04 13:07:51','2023-12-04 13:07:51',NULL,'22157584-fdf0-40c9-817d-207e92689d61');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qnmoxgmcnjtfcakqjoqfnrveejtgzyvgxtkm` (`structureId`,`elementId`),
  KEY `idx_teymxqpljjwdnqddfkrfvypqsnvoajbhemoq` (`root`),
  KEY `idx_deiijkkwnqiwtbsclcerjsllrrarosjbsmsc` (`lft`),
  KEY `idx_rdrkqsgksmbtnovefppaforgnomawvzzbrev` (`rgt`),
  KEY `idx_chmjiaczlqipbawishsyjpnmlqeeawhqvzub` (`level`),
  KEY `idx_kjxeinmerbjyxnebqjiqjgbtvwtapwbjawos` (`elementId`),
  CONSTRAINT `fk_vljrkjozcfyshcrfkbomzlqalfhxctcaxsto` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_buaozuwznzkqfmnveitkhwthplujoatmfkzi` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_stmhngmbqmouwuycctebzmcsadjrdebwviri` (`key`,`language`),
  KEY `idx_lrfgwrwtqcootzkqlfntzwkcmvyxvybzrzvt` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yujyouldbmwdxiezmedpumcxxmbplnbwyscb` (`name`),
  KEY `idx_yxtbqovvkjbxenjntulnaluykowmyhgshqdr` (`handle`),
  KEY `idx_azydqdzfrwijvyuxpglzbcweoyvlgkxzslnc` (`dateDeleted`),
  KEY `fk_wdqwljwfnxmkuktobwgsewaqhihrwasmzlzh` (`fieldLayoutId`),
  CONSTRAINT `fk_wdqwljwfnxmkuktobwgsewaqhihrwasmzlzh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_umovajyppxvedergmsnqcvbhguipajandobi` (`groupId`),
  CONSTRAINT `fk_qqrxusbtspallqtncuaafsjqzjwrrccrebwf` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rwsajsglqnywbbxcwesilnnuiuahdfkpkkid` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_voopbwanktobmbesnlsnlxuhjmtwpywfxyvk` (`token`),
  KEY `idx_larklqrzdrkeaxncollpcghitjnfkkbdbcly` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kwbyskcsvwkngsuawcddowaczqrwhffiyxnm` (`handle`),
  KEY `idx_oxtxeiblxfpfzoivnlzjqbhzegdowapzdnfi` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wvlwmqzpsdpzaukfbckcgotxahllcqxysizh` (`groupId`,`userId`),
  KEY `idx_tzbcqknbxhrxqatoveqfduvviwozotndcklv` (`userId`),
  CONSTRAINT `fk_hhnywxrguosfhlaotxowmqrlgcgacwzvvlxk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tfzlswlazubwuqlysbooaxzgajyceediocpn` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bvtvrfcdvrnemlvjlmiwwhfiqcfmrvvnuesm` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wkqxtgzfvllzdocrmliegrpbktgejqodgfes` (`permissionId`,`groupId`),
  KEY `idx_ojszdjcswclrfcgkskabkfwxmcpxcxodtbet` (`groupId`),
  CONSTRAINT `fk_cebcetrkwijocsmjtutgzzvcgjghsxviwvzd` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_letkobmknmlykdqperfkssxykqycnnlpeaun` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qnkjxzntahdwajwevdldubscwmuznrmnqutq` (`permissionId`,`userId`),
  KEY `idx_hpqeqsnntfhssmniodlxehafipisqjcgufqf` (`userId`),
  CONSTRAINT `fk_hhwzmijnochbqwrgjnprsvankgbnynjbqbel` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qpnvohbjglkyvvndpehiwymzfsiulwnmufrb` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_qnjydxglzfkhryfqquxjvbuxxssucbenbncl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\",\"locale\":null,\"weekStartDay\":\"1\",\"alwaysShowFocusRings\":false,\"useShapes\":false,\"underlineLinks\":false,\"notificationDuration\":\"5000\",\"showFieldHandles\":false,\"enableDebugToolbarForSite\":false,\"enableDebugToolbarForCp\":false,\"showExceptionView\":false,\"profileTemplates\":false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uukgdqctwqyrznotjlefccsxonubtlqlkieb` (`active`),
  KEY `idx_uvwlxmfpmhomusdqfyhxkuebokqquymfyegk` (`locked`),
  KEY `idx_ypgctjutcxphdoopxfymxutmsujtxklhvnyk` (`pending`),
  KEY `idx_ffrcbmrgilylwmwpzlhkuqoltuqkyqdmssom` (`suspended`),
  KEY `idx_bxprfoufhtvelbblvvtarziskebsexnoxzkp` (`verificationCode`),
  KEY `idx_yhwvsbshclrhwiztoqslccnzifahvjpndmpi` (`email`),
  KEY `idx_aqrifntyijoorxithtdsehxfshfwhcqkpubt` (`username`),
  KEY `fk_hryyfwkdeeqwcnnzfynenrmqappufqevhihq` (`photoId`),
  CONSTRAINT `fk_hryyfwkdeeqwcnnzfynenrmqappufqevhihq` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lgxfblvdzvzoxgssczsbjdjgdttcbefvoubg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin','',NULL,NULL,'admin@test.be','$2y$13$RAlYl/dv9s1AlyP2fVvW6udAGE.LEYBWnov2Jr3Noy1q7/XH7.t/C','2023-12-08 14:45:12',NULL,'2023-12-08 14:46:24',1,'2023-12-08 14:46:24',NULL,1,NULL,NULL,NULL,0,'2023-12-04 13:07:52','2023-12-04 13:07:52','2023-12-08 14:46:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gcbyhmqingnlkrnnmhnhitfilojtibpevudf` (`name`,`parentId`,`volumeId`),
  KEY `idx_ethtlhxxdustduqvsovpfmcvnfilahqocrna` (`parentId`),
  KEY `idx_mdqsvmcmlpbnhilgmhzgcbpbctsnpdalgqim` (`volumeId`),
  CONSTRAINT `fk_snnxtotpagagwgcqmqkaulfppuwecmqojcuq` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vaclxkylybeeaocvptcfkyvdegydgtpwwhqx` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'news-assets','','2023-12-04 13:35:36','2023-12-04 13:35:36','5a7f5880-9226-4a0f-9e5a-f0909c34a704'),(2,NULL,NULL,'Temporary filesystem',NULL,'2023-12-04 13:43:45','2023-12-04 13:43:45','d8b5e68e-4fd3-4c5f-be6e-e150cfaefa59'),(3,2,NULL,'user_1','user_1/','2023-12-04 13:43:45','2023-12-04 13:43:45','1800e677-51c4-491f-be9d-0b303f6a3d08');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ejybhobmddjegvjbixtehwysstnbyfjpcqio` (`name`),
  KEY `idx_vmjsanbotisdvxrsptbkzfpnwfdtftmsushu` (`handle`),
  KEY `idx_xzaqytuxqobxfmhfstwhnytdnyhqmpocuzgm` (`fieldLayoutId`),
  KEY `idx_zbakwwbgjnujwfmhhrvkupkmnymexehhjvch` (`dateDeleted`),
  CONSTRAINT `fk_zpesnmssrxgkjcfselzubdpotmixvjsvwjss` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,2,'news-assets','newsAssets','assets','assets','','site',NULL,1,'2023-12-04 13:35:36','2023-12-04 13:35:36',NULL,'027709b3-b422-4204-9597-c132f25a8567');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eqojtnukmlqlozjvdyujtqmotsxaiefbwtld` (`userId`),
  CONSTRAINT `fk_yznwvkpiwupmxihyulgocizsgoalbwlrmeqo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-12-04 13:22:20','2023-12-04 13:22:20','392fcccc-236f-47c2-94a1-167f50050ac4'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-12-04 13:22:20','2023-12-04 13:22:20','5e9b8a71-f76b-4e78-9227-f9b936c5a682'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-12-04 13:22:20','2023-12-04 13:22:20','b4795a5d-14c8-4470-ba71-96220c0bd0ac'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-12-04 13:22:20','2023-12-04 13:22:20','d1519f62-583c-4fc8-99ec-b655ceddb6b6');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-08 14:49:15
